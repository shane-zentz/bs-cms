<?php
error_reporting(0);
/*
Class: Menu
Author: Shane Zentz 2020
Desc: This class creates the menu for all pages in the cms/website.

*/
class Menu{
  // the main menu file to save the users menu
  protected $menuFile = 'admin/menu.json';
  protected $menuFile2 = '../admin/menu.json';

 // constructor
  public function __construct() { 
 // echo 'new sitemap object...<br>';
 }
  
  // method to get available links, and add custom links to the nestable menu page,
  // will save the menu to menu.json file on user save, also will read the saved
  // menu.json file to populate the menu side of the menu page...
  public function getMenuLinks(){
   // for now, just output all pages titles/urls to an ul:::
   $xml = simplexml_load_file('database/pages.xml');
   //var_dump($xml);
   $list = $xml->page;
   //var_dump($list);
   $baseURL = sprintf(
    "%s://%s%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
    $_SERVER['SERVER_NAME'],
    $_SERVER['REQUEST_URI']
  );
  
  
    //echo $baseURL;
	$baseURL2 = str_replace('admin/sitemapTest.php',"",$baseURL);
	//echo '<br><br>Real Base URl: '.$baseURL2;
	
	$baseURL2NS = rtrim( $baseURL2, '/' );
  // echo '<h2>Sitemap</h2><ul><li><a href="/">Homepage</a></li>';

  echo '<h3>Add Custom Links</h3><form action="" class="form-group"><label for="customName">Text:</label><br><input type="text" name="customName" id="customName" class="form-control form-control-lg"><br><label for="customURL">URL:</label><br><input type="text" name="customURL" id="customURL" class="form-control form-control-lg"> </form><button value="Submit" id="addCustom" class="btn btn-primary btn-lg mr-2 w-100 buttonHeight">Add Link</button>';
  echo '<div class="row"><div class="cf nestable-lists">
           <div class="col-sm m-2"><h3 style="text-align:center">Available Pages</h3>
        <div class="dd" id="nestable">
            <ol class="dd-list">';
   for ($i = 0; $i < count($list); $i++) {
	 //  if ($list[$i]->pageURL != "/") {
	   //echo '<li><a href="'.$baseURL2NS.$list[$i]->pageURL.'">'.$list[$i]->pageTitle.'</a></li>';
	   
	   echo '<li class="dd-item" data-id="'.$list[$i]->pageTitle.'" data-url="'.$list[$i]->pageURL.'">
                    <div class="dd-handle">'.$list[$i]->pageTitle.'    -     '.$list[$i]->pageURL.'</div>
                </li>';
	   
	   
   }
   // probably the worst recursive function ever written, lol... but somehow it works???
			
	$read = file_get_contents($this->menuFile2);
	 $reads = json_decode($read, true);
	 //var_dump($reads);
	echo '</ol></div></div><div class="col-sm m-2"><h3 style="text-align:center">Main Menu:</h3><div class="dd" id="nestable2">
            <ol class="dd-list">';
	foreach ($reads as &$key) {
		echo '<li class="dd-item" data-id="'.$key['id'].'" data-url="'.$key['url'].'"><div class="dd-handle">'.$key['id'].'</div>';
	if ($key['children']){echo '<ol class="dd-list">';foreach ($key['children'] as &$keys) {
		
		echo '<li class="dd-item" data-id="'.$keys['id'].'" data-url="'.$keys['url'].'"><div class="dd-handle">'.$keys['id'].'</div>';
		
		if ($keys['children']){echo '<ol class="dd-list">';foreach ($keys['children'] as &$keys2) {
		
		echo '<li class="dd-item" data-id="'.$keys2['id'].'" data-url="'.$keys2['url'].'"><div class="dd-handle">'.$keys2['id'].'</div></li>';}echo '</ol>';}
		else {echo '</li>';}
		echo '</ol>';
		}
		
	}
	else{ echo '</li>';}
	}
	echo '</ol></div></div></div></div>'; 
			
	echo '
    <textarea id="nestable-output" hidden></textarea><br><form action="" method="POST">
    <textarea id="nestable2-output" name="nestable2-output" hidden></textarea><input type="submit" name="submit" value="Save Menu" class="btn btn-primary btn-lg mr-2 w-100 buttonHeight">
</form>
	<br><br><hr><br><br>
	';
	   if(isset($_POST['submit'])){
     // means submit clicked!

     $query = $_POST['nestable2-output'];
     //echo $query;  // insert this to menu.json on save...
	 file_put_contents($this->menuFile2, $query);
		   echo '<script type="text/javascript">alert("Menu Saved...");
    if ( window.history.replaceState ) {
        window.history.replaceState( null, null, window.location.href );
    }
</script>';

	 //header("refresh:2; index.php"); // really should be a fully qualified URI
     //echo '<script type="text/javascript">alert("Menu Saved...");</script>';
     //$ret = json_decode($query,true,JSON_PRETTY_PRINT);
	 //echo $ret;
     //print_r($_POST) // check the values of $_GET array..
   }			
			
  } 
  
  // get the menu for the theme / site from the saved menu.json file...
  public function getMenu(){
	  $read = file_get_contents($this->menuFile);
	  //var_dump($read);
	 $reads = json_decode($read, true);
	 //var_dump($reads);
	echo '<h3 style="text-align:center">Main Menu for Theme:</h3><div class="" id="">
            <ul class="">';
	foreach ($reads as $key) {
		echo '<li class=""><a href="'.$key['url'].'">'.$key['id'].'</a>';
	if ($key['children']){echo '<ul class="">';foreach ($key['children'] as &$keys) {
		
		echo '<li class=""><a href="'.$keys['url'].'">'.$keys['id'].'</a>';
		
		if ($keys['children']){echo '<ul class="">';foreach ($keys['children'] as &$keys2) {
		
		echo '<li class=""><a href="'.$keys2['url'].'">'.$keys2['id'].'</a></li>';}
		echo '</ul>';}
		else {echo '</li>';}
		echo '</ul>';
		}
		
	}
	else{ echo '</li>';}
	}
	echo '</ul></div>'; 
  }
  
    // get the menu for the theme / site from the saved menu.json file...
  public function getMenu2(){
	  $read = file_get_contents($this->menuFile);
	 $reads = json_decode($read, true);
	 //var_dump($reads);
	$out = '<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top navbar-hover">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent"><ul class="navbar-nav mx-auto">';
	foreach ($reads as $key) {
		if (!$key['children']){$out .= '<li class="nav-item"><a href="'.$key['url'].'" class="nav-link">'.$key['id'].'</a>';}
	if ($key['children']){$out .= ' <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="'.$key['url'].'" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                    '.$key['id'].'
                </a>
                <ul class="dropdown-menu">';foreach ($key['children'] as $keys) {
		
		$out .= '<li><a href="'.$keys['url'].'" class="dropdown-item">'.$keys['id'].'</a>';
		
		if ($keys['children']){$out .= '<ul class="dropdown-menu">';foreach ($keys['children'] as $keys2) {
		
		$out .= '<li class=""><a href="'.$keys2['url'].'" class="dropdown-item">'.$keys2['id'].'</a></li>';}
		$out .= '</ul>';
							  }
		else {$out .= '</li>';}
		//$out .= '</ul>';
		}
		$out .= '</ul>';
	}
	else{ $out .= '</li>';}
	}
	$out .= '</ul></div></nav>'; 
	return $out;
  }
  
}