<?php
error_reporting(0);
/*
BS-CMS (c) 2020 by Shane Zentz
This file simply outputs everything from the pages.xml database file
not very useful, just used to quickly check what is in the main page
file from the backend admin panel...
*/

$xml = simplexml_load_file('database/pages.xml');

$list = $xml->page;

for ($i = 0; $i < count($list); $i++) {

    echo 'Index: ' . $list[$i]->index . '<br>';

    echo 'Page Title: ' . $list[$i]->pageTitle . '<br>';
	
	echo 'Meta Title: ' . $list[$i]->metaTitle . '<br>';
	
	echo 'Meta Description: ' . $list[$i]->metaDescription . '<br>';
	
	echo 'page URL: ' . $list[$i]->pageURL . '<br>';
	
	echo 'Template: ' . $list[$i]->template . '<br>';
	
	echo 'Body Contents: ' . base64_decode($list[$i]->bodyContents). '<br>';
	
	echo '<br><br><br>';

}

?>