<?php
  /*
  BS-CMS (c) 2020 by Shane Zentz
  This file just outputs basic info for the admin dashboard (entry point / start page for admin dashboard)
  */
   session_start();

if (!isset($_SESSION['nID']))
{
    header("Location: admin-login.php");
    die();
} 
  include('cmsClass.php');
  $cms = new CMS();
  $version = $cms->getVersion();
  echo '<div class="card-deck m-2"> <div class="card"><div class="card-header text-dark text-center" style="font-weight:bold;font-size:large">Server:</div><div class="card-body bg-light text-dark">';
  echo '<h5>Server URI: '.$_SERVER[HTTP_HOST].'</h5>';
  echo '<h4 class="text-center">Server Header Information</h4>';
  print_r(get_headers('https://'.$_SERVER[HTTP_HOST]));
  echo '</div></div>';
  
  $date = date('H:i:s m-d-Y');
  echo '<div class="card"><div class="card-header  text-dark text-center" style="font-weight:bold;font-size:large">Information:</div><div class="card-body bg-light text-dark"><h5>'.$date.'</h5></div></div></div>';

  echo '<div class="card-deck m-2"><div class="card"><div class="card-header text-dark text-center" style="font-weight:bold;font-size:large">System:</div><div class="card-body bg-light text-dark">';
  echo '<h5>BS-CMS Version: '.$version.'</h5>';
  echo '<h6>Available Updates</h6>';
  echo '<img src="images/bs-logo.jpg" alt="bs-logo" width="180px" class="align-img-center" />';
  echo '</div></div>';
  echo '<div class="card"><div class="card-header text-dark text-center" style="font-weight:bold;font-size:large">User:</div><div class="card-body bg-light text-dark">';
  echo '<h5>Your Information</h5>';
  $yourBrowser = $_SERVER['HTTP_USER_AGENT'];
  echo '<h5>Your Browser: '.$yourBrowser.'</h5>';
    $yourIP = $_SERVER['REMOTE_ADDR'];
  echo '<h5>Your IP: '.$yourIP.'</h5>';
  echo '</div>';
  echo '</div></div>';
?>