<?php
/* 
   BS-CMS (c) 2020 by Shane Zentz
   process the install file,
   
   if the user got this far, they must have supplied at least
   a username and password, so run the install script........


*/

require_once('userClass.php');
require_once('activityClass.php');

// The post/file variables from form...
$siteAdmin = $_POST['siteAdmin'];
$siteAdminPassword = $_POST['siteAdminPassword'];
$siteTitle = $_POST['siteTitle'];                             
$siteFavicon = $_FILES["faviconUpload"]["name"];  					           
$siteLogo = $_FILES["logoUpload"]["name"];                    

// for now, just output the data...
echo '<h2>Form Results</h2>';
echo '<h4>Site Administrator: '.$siteAdmin.'</h4>';
echo '<h4>Site Admin Password: '.$siteAdminPassword.'</h4>';
echo '<h4>Site Title: '.$siteTitle.'</h4>';
echo '<h4>Site Favicon: '.$siteFavicon.'</h4>';
echo '<h4>Site Logo: '.$siteLogo.'</h4>';

echo '<h6>End of data</h6>';


////////////////////////////////////////////////////////////////////////////////////
// check for required write permissions, mod rewrite, etc...




////////////////////////////////////////////////////////////////////////////////////
// move the uploaded files (if any) to /uploads/user/settings in the admin folder...
//$target_dir = "admin/uploads/user/settings/";
$target_dir2 = "uploads/user/settings/";
$target_file = $target_dir2 . basename($_FILES["faviconUpload"]["name"]);
$target_file2 = $target_dir2 . basename($_FILES["logoUpload"]["name"]);
$target_fileActual = $target_dir2 . basename($_FILES["faviconUpload"]["name"]);
$target_file2Actual = $target_dir2 . basename($_FILES["logoUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
	echo 'SUBMIT IS SET...<br>';
  $check = getimagesize($_FILES["faviconUpload"]["tmp_name"]);
  $check2 = getimagesize($_FILES["logoUpload"]["tmp_name"]);
  if($check !== false) {
	  $uploadFavicon = true;
	  
    echo "File is an image - " . $check["mime"] . ".<br>";
    $uploadOk = 1;
  } else {
    echo "File is not an image.<br>";
    $uploadOk = 0;
  }
  if($check2 !== false) {
	  $uploadLogo = true;
    echo "File is an image - " . $check["mime"] . ".<br>";
    $uploadOk = 1;
  } else {
    echo "File is not an image.<br>";
    $uploadOk = 0;
  }
}

// Check file size
if ($_FILES["faviconUpload"]["size"] > 500000 || $_FILES["logoUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.<br>";
  $uploadOk = 0;
}

// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br>";
  $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType2 != "jpg" && $imageFileType2 != "png" && $imageFileType2 != "jpeg"
&& $imageFileType2 != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br>";
  $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.<br>";
// if everything is ok, try to upload file
} else {
	
if ($uploadFavicon == true){
  if (move_uploaded_file($_FILES["faviconUpload"]["tmp_name"], $target_file)) {
    echo "The file ". basename( $_FILES["faviconUpload"]["name"]). " has been uploaded.<br>";
} else {
    echo "Sorry, there was an error uploading your file.<br>";
}}
if($uploadLogo == true){
  if (move_uploaded_file($_FILES["logoUpload"]["tmp_name"], $target_file2)) {
    echo "The file ". basename( $_FILES["logoUpload"]["name"]). " has been uploaded.<br>";
  } else {
    echo "Sorry, there was an error uploading your file.<br>";
}}
}



////////////////////////////////////////////////////////////////////////////////////
// insert Site Title (if any) into the settings xml file...

// load the settings document... (JUST A TEST FILE FOR NOWS)...
$file = 'database/settings.xml';

    $xml = new DOMDocument();
    $xml->load($file);
	
	$record = $xml->getElementsByTagName('system');
    foreach ($record as $person) {
		echo 'entering for loops..<br>';
            $person->getElementsByTagName('siteTitle')->item(0)->nodeValue = $siteTitle;
			$person->getElementsByTagName('siteFavicon')->item(0)->nodeValue = $target_fileActual;
			$person->getElementsByTagName('siteLogo')->item(0)->nodeValue = $target_file2Actual;
	}
	
	// save the file...
	$xml->save($file);
     echo 'settings file has been written...<br>';
	

////////////////////////////////////////////////////////////////////////////////////////
// create the user with username and password...



// create new user object
$user = new User();
$act = new Activity();

// get the data from the form submit
//$siteAdmin = $_POST['siteAdmin'];
//$siteAdminPassword = $_POST['siteAdminPassword'];

// call the addUser method to create the new user...
// echo alert if the user was created, an error message otherwise...
if ($user->createUser ($siteAdmin, $siteAdminPassword))
{
  $act->addActivity($siteAdmin, "Added new user: ".$siteAdmin);
  echo 'user added...<br><br>';
}
else {echo 'user creation failed :(.....<br>';}


////////////////////////////////////////////////////////////////////////////////////////
// update htacces to change directoryindex from install.php to index.php...
  // for now see if i can just add some random text to htaccess (as a comment)
 //$file = fopen('.htaccess', 'a') or die('Fail to open .htaccess file');

$data = 'DirectoryIndex index.php'.PHP_EOL;
        //    fwrite($file, $line.PHP_EOL);

       // fclose($file);
		
		$f = "../.htaccess";

// read into array
if($arr = file($f)){

// edit first line
$arr[0] = $data;

// write back to file
file_put_contents($f, implode($arr));
		
echo 'wrote to htaccess...<br>';
}
else{echo 'htaccess not updated...<br>';}


///////////////////////////////////////////////////////////////////////////////////////
// delete the install.php file in root directory
unlink('../install.php');

///////////////////////////////////////////////////////////////////////////////////////
// redirect the new user to postinstall.php (which contains links for homepage and admin panel)...

echo '<br><br>redirecting to postinstall.php ... Please Wait ...<br><br>';
header("refresh:2; /"); // really should be a fully qualified URI
echo '<script type="text/javascript">alert("System Installed ...");</script>';
?>