<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is for getting all the available themes and displaying them
for the user in the admin panel...
*/
require_once('themeClass.php');
$dir = '../themes';
$themeTest = new Theme($dir);
$themeTest->getTheme($dir);
?>
<h2 class="text-center p-2">Themes</h2>

<!-- get all the themes from the /themes directory -->
<?php
$themeTest->getAllThemes();
?>

   <div class="form-group mt-4">
	<button type="submit" value="themeSetActive" name="themeSetActive" class="btn btn-primary btn-lg mr-2 w-100 buttonHeight">Set Active Theme</button>
   </div>
</form>
