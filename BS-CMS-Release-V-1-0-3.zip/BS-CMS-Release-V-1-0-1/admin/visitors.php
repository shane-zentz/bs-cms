<h2>Visitors Log</h2>

<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is just for tracking users of the BS-CMS website
*/

$dir = 'database';
if(!is_dir($dir)){	mkdir($dir,0777);
}
$file = 'visitors.txt';
$ip = $_SERVER['REMOTE_ADDR'];
$filename = $dir.'/'.$file;


//$fp = fopen($filename, 'a+');


$url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";
$info = '
===========================
IP: '.$ip .'
Time: '.date('d/m/Y H:i:s a').'
Filename: '.basename($_SERVER['PHP_SELF']).'
URL: '.$url.'
';
file_put_contents($filename, $info, FILE_APPEND);


$file = file_get_contents($filename, true);
$lines = explode(PHP_EOL, $file);

foreach ($lines as $line) {
    if (strpos($line, '/') === false) {
       $line = htmlspecialchars($line . "\n");
       echo nl2br($line);
	   //echo $line;
    }
}
//fclose($fp);
?>