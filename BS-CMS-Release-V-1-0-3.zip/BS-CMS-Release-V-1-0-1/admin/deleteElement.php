<?php
/*
BS-CMS (c) 2020 by Shane Zentz
this file is to delete a page from the page.xml database file,
*/
session_start();

if (!isset($_SESSION['nID']))
{
    header("Location: admin-login.php");
    die();
} 
//if (isset($_POST['deletePage'])) {
	require 'sitemapClass.php';
require_once('activityClass.php');
$act = new Activity();
//$id=$_POST['deletePage'];
function delete_record($id, $file)
{
    $xml = new DOMDocument();
    $xml->load($file);
    
    $record = $xml->getElementsByTagName('page');
    foreach ($record as $person) {
        $person_id = $person->getElementsByTagName('index')->item(0)->nodeValue;
        //$person_name=$person->getElementsByTagName('name')->item(0)->nodeValue;
        if ($person_id == $id) {
            $id_matched = true;
            $person->parentNode->removeChild($person);
            
            break;
        }
    }
    if ($id_matched == true) {
        if ($xml->save($file)) {
            return true;
        }
    }
    
}


$file = "database/pages.xml";
if (file_exists($file)) {
    if (isset($_POST['deletePage']) && ctype_digit(trim($_POST['deletePage']))) {
        $id = trim($_POST['deletePage']);
        
        if (delete_record($id, $file)) {
			$act->addActivity($_SESSION["username"], "Deleted Page: ".$_POST['deletePage']);
			$sitemap = new Sitemap();
$sitemap->generateSitemap();
            header("refresh:2; index.php"); // really should be a fully qualified URI
echo '<script type="text/javascript">alert("Page Deleted...");window.history.back();</script>';
        } else {
            echo "$id not removed";
        }
        
    } else {
        echo "id missing";
    }
} else {
    echo "$file missing";
}

?>