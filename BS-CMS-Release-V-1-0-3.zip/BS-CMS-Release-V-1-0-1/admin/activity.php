<h2>Activity Logs</h2>
<?php
/* BS-CMS (c) 2020 by Shane Zentz
   this file just gets all activities from the CMS
*/
header('Content-Type: text/plain');
require 'activityClass.php';

$act = new Activity();

// get the entire activities file...?
echo $act->getActivities();
?>