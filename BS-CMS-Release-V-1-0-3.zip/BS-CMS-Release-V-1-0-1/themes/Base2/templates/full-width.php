<!-- Start the main container -->
<div class="container-fluid" id="main">
  <!-- start main row -->
  <div class="row">
    <!-- start main col -->
	<div class="col">