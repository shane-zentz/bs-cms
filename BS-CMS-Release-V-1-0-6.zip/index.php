<?php
/* BS-CMS (c) 2020 by Shane Zentz ...
   This is the entry point for all front end pages of the CMS ...
   
   Ignore the commented out parts, they are just for testing purpose...
   
   UPDATED...5-1-2024
   
   * Removing the tracking section for now, maybe add back laters...
   * should be all working and ready, test with a few new themes, starting with blank,
     then make a flex theme to test????
   * 404 page may not be working, will need to test further....
   
   Now, needs to figure out how to get the meta title and description into pages....
   one solution would be to 'seperate out header into two parts, head.php with top html code,
   then call the title and description here (just like in original index.php file, then header.php
   with the rest of the head code???
   
*/

// Include router class, theme class, menu class...
include('Route.php');
require_once('admin/themeClass.php');
require_once('admin/menuClass.php');
$menu = new Menu();
$dir = 'themes';
$themeTest = new Theme($dir);
$themeTest->getTheme($dir);

// get the requested URI...
$request = $_SERVER['REQUEST_URI'];
//echo 'Request uri: '.$request.'<br>';

// the Document Root 
$docROOT = dirname($_SERVER['PHP_SELF']);
//echo 'Doc Root: '.$docROOT.'<br>';
//remove the doc root from the request URI
$requestURL = str_replace($docROOT, "", $request);
//echo 'Request URL: '.$requestURL.'<br>';


// first need to find out if page requested exists in pages.xml, if so add the route,
// if not then do not add the route and 404 shouldst be triggered...
// first get an array with all the page uris

// load the main pages database xml file...
$xml2 = simplexml_load_file('admin/database/pages.xml');

$lists = $xml2->page;

// go through the entire list of pages to find the requested one...
for ($i = 0; $i < count($lists); $i++) {
	$checks = $lists[$i]->pageURL;

// next go through whole array to see if $GLOBALS["requestURL"] is in it...
//echo 'Check: '.trim($checks).'  ...  request: /'.trim($request).'<br>';
if (strcmp(trim($checks),trim($request))===0) {
//echo 'TRUE: <br><br>';
// if so, then...
// get route example to get any page except homepage...
Route::add($request,function(){
	showPage($request);
},'get');
}

}


// anonomous function to find (and display) the requested page...
function showPage($names){
	//$favicons = $GLOBALS["settings"]->getFavicon();
	$pageFound = false;
// load the main pages database xml file...
$xml = simplexml_load_file('admin/database/pages.xml');

$list = $xml->page;

// go through the entire list of pages to find the requested one...
for ($i = 0; $i < count($list); $i++) {
	$check = $list[$i]->pageURL;
    // if the requested url is found...
	if (strcmp(trim($check),trim($GLOBALS["request"]))===0) {
		//echo 'CHECK: '.trim($check).' = '.trim($GLOBALS["request"]);
	$pageFound = true;
	
	//echo $GLOBALS["themeTest"]->getThemePart('','index.php');
	
	// Call the predefined head/top of html page, head.php
	echo $GLOBALS["themeTest"]->getThemePart('includes','head.php');
	
	// Call the meta title and description for the requested page...
	echo '<title> ' . $list[$i]->metaTitle . '</title>';
	echo '<meta name="description" content="' . $list[$i]->metaDescription . '">';
	
	// Call the theme header, required by all themes...
	echo $GLOBALS["themeTest"]->getThemePart('includes','header.php');
	
	// Call the builtin (bootstrap) menu 
	echo $GLOBALS["menu"]->getMenu2();
	
	// Optionally, if your theme does not use the bootstrap (4) menu system, then you
	// can call this generic Menu function, which just outputs a nav with ul/li items (nested)
	// that your theme will need to style up...
	//echo $GLOBALS["menu"]->getMenu();
	
	// Or, optionally, if you do not want to use the built in menu system at all,
	// you can comment both of the menu methods above out and add the menu to your header file,
	// but if you do that then the menu tab in the admin panel will not affect your site at all,
	// and you will need to manually make any menu changes or adjustments in your theme files...
	
	// get the template used (if any)
	echo $GLOBALS["themeTest"]->getTemplatePart($list[$i]->template);
	
	// the body contents from the database file...	
	echo base64_decode($list[$i]->bodyContents);

	// Call in the theme footer (required by all themes)....
	echo $GLOBALS["themeTest"]->getThemePart('includes','footer.php');


	
	}

}
// Send user to a 404 if page isn't found....
if (!pageFound) {header("HTTP/1.0 404 Not Found");echo '<h1>404</h1>';}
}

//Run the page...
Route::run('/');

?>