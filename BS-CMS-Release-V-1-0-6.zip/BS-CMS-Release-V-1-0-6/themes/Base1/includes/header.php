<!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
	
	<!-- lightbox css -->
	<link href="../lightbox/css/lightbox.min.css" rel="stylesheet" />
	
	<meta name="theme" content="Base 1" />
	<meta name="author" content="Shane Zentz" />
	
