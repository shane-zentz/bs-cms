<?php
/*
Class: Update
Author: Shane Zentz 2021
Desc: The updating class for BS-CMS. This class is for checking for updates and performing updates, based on
      checking the currently installed version with the latest github commit...
      //please ignore the commented out code, its just for testing...
	  
	  // currently seems to be completely working except for the button part of the update,
	  // fix that up and then its should be dones.

*/


class updateCMS {
	
 // constructor
  function __construct(){}
  
  // settings file to get current cms version:
  protected $settingsFile = 'database/settings.xml';
  
  // the latest cms version:
  protected $latest = '';
  
  // get the current version of this here cms...
  public function getCurrentVersion(){  
  $xml = simplexml_load_file($this->settingsFile);
	// get a the system xml file
    $list = $xml->system;
	for ($i = 0; $i < count($list); $i++) {
	  $version = $list[$i]->sysVersion;
	}
	return $version;
  }
  
  // find out the latest version from github commit...
  public function getLatestRemoteVersion()
  {
	// hardcoding the githubs url because it should never change...
    $url2 = "https://api.github.com/repos/shane-zentz/bs-cms/tags";
    $ch2=curl_init($url2);
    curl_setopt($ch2, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch2, CURLOPT_USERAGENT, "test");
    $r2=curl_exec($ch2);
    if($r2 === false) {     echo 'Curl error: ' . curl_error($ch2); }
    curl_close($ch2);
    $response_array2 = json_decode($r2, true);
    $output = $response_array2[0]["name"];
    return $output;
  }
  
  // compare installed version with the latest github commit version...
  public function compareVersions()
  {
    $needsUpdate = false;
	$remoteVersion = str_replace('V-','',$this->getLatestRemoteVersion());
	$currentVersion = str_replace('V-','',$this->getCurrentVersion());
	if (version_compare($remoteVersion, $currentVersion) > 0)  // something like that...
	  { $needsUpdate = true; // system needs to be updated
	    
	  }
	return $needsUpdate;
   }
  
  // Check if any updates are available, if so output update routine button, if not output message 'no update needed'
  public function checkForUpdates()
  {
    // first find out if we needs to update
	$shouldWeUpdate = $this->compareVersions(); // bool to let us know if we needs to update...
	// if we should updates, then put out the message...
	if ($shouldWeUpdate) // yes 
	{
	  /*$updateComment = '<div class="alert alert-danger p-2" role="alert">
        <h4 class="alert-heading text-center">An Update is Available!</h4><p class="text-center">Please update, Please remember to backup your system first.</p><p class="text-center"><button type="submit" name="checkUpdates" class="btn btn-primary btn-lg mx-auto text-center" onclick="'.$this->updateSystem().'">Update Now!</button></p></div>';
		*/
	  // try this:
	  $updateComment = '<form action="updateSystem.php" method="post"><div class="alert alert-danger p-2" role="alert">
        <h4 class="alert-heading text-center">An Update is Available!</h4><p class="text-center">Please update, Please remember to backup your system first.</p><p class="text-center"><button type="submit" name="submit" class="btn btn-primary btn-lg mx-auto text-center">Update Now!</button></p></div></form>';
	}
	// otherwise, nothing to update, output no updates message...
	else 
	{
	  //$updateComment = '<div class="alert">You are using the latest version...no need to update</div>';
	  $updateComment = '<div class="alert alert-success p-2" role="alert">
          <h4 class="alert-heading text-center">No Update Needed</h4><p class="text-center">You are using the latest version of BS-CMS!</p></div>';
	}
	return $updateComment;
  }
  
  // a recursive method to copy files from src to dst...
  public function recurse_copy($src,$dst) {
    $dir = opendir($src);
    @mkdir($dst);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            if ( is_dir($src . '/' . $file) ) {
                $this->recurse_copy($src . '/' . $file,$dst . '/' . $file);
            }
            else {
                copy($src . '/' . $file,$dst . '/' . $file);
            }
        }
    }
    closedir($dir);
  }

  // a method to delete a folder and all files within, used to delete the
  // temp update folder here...
  public function rrmdir($src) {
    $dir = opendir($src);
    while(false !== ( $file = readdir($dir)) ) {
        if (( $file != '.' ) && ( $file != '..' )) {
            $full = $src . '/' . $file;
            if ( is_dir($full) ) {
                $this->rrmdir($full);
            }
            else {
                unlink($full);
            }
        }
    }
    closedir($dir);
    rmdir($src);
  }
  
  // if the user has clicked the update button, update the systems...
  public function updateSystem()
  {
    $urlz = "https://bs-cms.shanezentz.com/official-release/BS-CMS-LATEST.zip";  // this works!!!
    $zipFilez = "updateMES.zip"; // Local Zip File Path
    $zipResource = fopen($zipFilez, "w+");
    // Get The Zip File From Server+
    $ch4 = curl_init();
    curl_setopt($ch4, CURLOPT_URL, $urlz);
    curl_setopt($ch4, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch4, CURLOPT_BINARYTRANSFER, 1);
    curl_setopt($ch4, CURLOPT_FOLLOWLOCATION, 1);
    curl_setopt($ch4, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.9.2.3) Gecko/20100401 Firefox/3.6.3'); 
    curl_setopt($ch4, CURLOPT_VERBOSE, 1);
    curl_setopt($ch4, CURLOPT_SSLVERSION, 6);
    curl_setopt($ch4, CURLOPT_TIMEOUT, 10);
    curl_setopt($ch4, CURLOPT_FILE, $zipResource);
    $page = curl_exec($ch4);
      if(!$page) {
        echo "Error :- ".curl_error($ch4);
       }
      else {//echo "<br>update.zip downloaded...<br><br> ";
       }
    curl_close($ch4);

    /* Open the Zip file */
    $zip = new ZipArchive;
    $extractPath = "tempUpdates";
    if($zip->open($zipFilez) != "true"){
      echo "Error :- Unable to open the Zip File";
    } 
    /* Extract Zip File */
    $zip->extractTo($extractPath);
    $zip->close();

    // copy the updated files to the tempUpdates dir...
    $this->recurse_copy('tempUpdates','../');

	// delete temp working dir and files within...
	$this->rrmdir('tempUpdates');
	
	// update settings file with installed version
	$file = $this->settingsFile;
	$xml = new DOMDocument();
    $xml->load($file);
	$latest = $this->getLatestRemoteVersion();
	
	$record = $xml->getElementsByTagName('system');
    foreach ($record as $person) {
		//echo 'latest version: '.$latest.'<br>';
            $person->getElementsByTagName('sysVersion')->item(0)->nodeValue = $latest;
	}
	// save the file...
	$xml->save($file);
	
	// all seems to be workin' except the update button, it just automatically updates 
	// when first loadin' the dashboard page, not what I want...
	
	
	// output messages about updatin'...
    header("refresh:2; /"); // really should be a fully qualified URI
    echo '<script type="text/javascript">alert("System Updated ...");</script>';
	
  }
  
}