<h2>Edit Current Users</h2>
<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is the form for displaying all system users, then the users can be
updated (password, only) or deleted...
*/
require 'userClass.php';

// create new user object
$user = new User();

// the array with all users/passes
$output = $user->getAllUsers();
$jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator($output,
    RecursiveIteratorIterator::SELF_FIRST));
	
	foreach ($jsonIterator as $key => $val) {
		//echo "KEY: ".$key."<br>VAl: ".$val."<br>";
		if ($key == 'User'){
		echo '<div class="alert bg-light text-dark p-1 m-2 row w-100"><div class="col-sm"><h5 class="text-left">User: <strong>'.$val.'</strong></h5></div>
		<div class="col-sm"><h5 class="text-right">Change password: &nbsp;&nbsp;</h5></div>
		<div class="col-sm"><form action="updateUser.php" method="post"><input type="hidden" name="userName" value="'.$val.'" /><input type="password"  name="updateUserPass" required>
	<button type="submit" class="btn btn-danger btn-sm" name="action" value="delete">Update Password</button></form></div>
		</div>
		';
		}
    }
?>

<hr>
<h3>Create New Users</h3>
<div class="alert bg-light text-dark p-2 m-2 row w-100">
		<div class="col-sm"><form action="addUser.php" method="post" class="form-inline"><div class="form-group p-2"><input type="text"  name="addUser" value="" placeholder="Username" required></div><div class="form-group p-2"><input type="password"  name="addPassword" value="" placeholder="Password" required></div>
	<button type="submit" class="btn btn-danger btn-sm" name="action" value="delete">Add New User</button></form></div>
		</div>


  <div class="row">
  <div class="col-sm ml-3">
  <button class="btn btn-primary p-3 m-3" onclick="gfg_Run()">
    Automatic Password Generator
  </button>
  </div>
  <div class="col-sm">
  <p>Remember to write the password down, or copy/paste to a file</p>
  <textarea id="geeks" rows="2" cols="50">&nbsp;</textarea> 
  </div>
  </div>
  
  
  
<div class="bg-light fixed-bottom text-dark collapse" id="collapsePassword">
    <div class="text-center py-3">
        <p class="mb-0">
            Generate a strong random password! Remember to write the password down, or copy/paste to a file.</p><p><button class="btn btn-primary" onclick ="gfg_Run()">Generate Password</button> 
        </p>
		<!--<p id="geeks">&nbsp;</p> -->
    </div>
	<script> 
        var el_down = document.getElementById("geeks"); 
  
        /* Function to generate combination of password */ 
        function generateP() { 
            var pass = ''; 
            var str = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ' +  
                    'abcdefghijklmnopqrstuvwxyz0123456789@#$!%^&*(){}[]?'; 
              
            for (i = 0; i <= 24; i++) { 
                var char = Math.floor(Math.random() 
                            * str.length + 1); 
                  
                pass += str.charAt(char) 
            } 
              
            return pass; 
        } 
  
        function gfg_Run() { 
            //el_down.innerHTML = generateP();
            var passes = generateP();			
			//alert("Generate a strong random password! Remember to write the password down, or copy/paste to a file."+"\n"+passes);
			el_down.innerHTML = passes;
        } 
    </script> 
</div>

<hr>