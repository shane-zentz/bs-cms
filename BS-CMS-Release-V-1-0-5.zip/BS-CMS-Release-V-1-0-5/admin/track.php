<?php

/* track.php

*/

$filename = 'database/visitors.txt';

$file = file_get_contents($filename, true);
$lines = explode(PHP_EOL, $file);

foreach ($lines as $line) {
    if (strpos($line, '/') === false) {
       $line = htmlspecialchars($line . "\n");
       echo nl2br($line);
	   //echo $line;
    }
}

echo '<br><hr><br>';
echo '<form action="deleteTacking.php" method="post"><p class="text-left"><button type="submit" name="submit" class="btn btn-primary btn-lg mx-auto text-center">Delete Tracking Contents!</button></p></form>';


?>