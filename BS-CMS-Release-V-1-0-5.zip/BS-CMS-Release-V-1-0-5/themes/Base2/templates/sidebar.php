<!-- start main container -->
<div class="container-fluid" id="main">
    <div class="row">
      <!-- include the sidebar -->
	  <div class="col-3 px-1 bg-light position-fixed" id="sticky-sidebar">
           <h3>This is the sidebar...</h3>
        </div>
	    <!-- the col -->
        <div class="col offset-3" id="">