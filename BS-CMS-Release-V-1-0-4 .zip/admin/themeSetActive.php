<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is the form for setting the active theme from within the admin panel...
*/
require 'themeClass.php';
$dir = '../themes';
$themeTest = new Theme($dir);
$themeTest->getTheme($dir);
 
if(isset($_POST['exampleRadios']))
   {
	//echo 'exampleRadios= '.$_POST['exampleRadios'].'<br>';
    $activeTheme = $_POST["exampleRadios"];
   }
   
$themeTest->setActiveTheme($activeTheme);

header("refresh:2; index.php"); // really should be a fully qualified URI
echo '<script type="text/javascript">alert("Active Theme Set...");</script>';
?>