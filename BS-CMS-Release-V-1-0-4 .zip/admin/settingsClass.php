<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This class is mainly for getting the favicon, logo image, and site title set by the user to the front end...
*/

class Settings{

protected $settingsFile = 'admin/database/settings.xml';


// Constructor
  public function __construct()
  {
  }
  
  // gets the favicon from the settings file...
  public function getFavicon(){
    $xml = simplexml_load_file($this->settingsFile);
	// get a the system xml file
	//var_dump($xml);
    $list = $xml->system;
	for ($i = 0; $i < count($list); $i++) {
	  $favicon = $list[$i]->siteFavicon;
	}
	return $favicon;
  }
  
  // get the logo from the settings file...  
  public function getLogo(){
    $xml = simplexml_load_file($this->settingsFile);
	// get a the system xml file
    $list = $xml->system;
	for ($i = 0; $i < count($list); $i++) {
	  $logo = $list[$i]->siteLogo;
	}
	return $logo;
  }
  
  // get the site title from the settings file...
  public function getTitle(){
    $xml = simplexml_load_file($this->settingsFile);
	// get a the system xml file
    $list = $xml->system;
	for ($i = 0; $i < count($list); $i++) {
	  $title = $list[$i]->siteTitle;
	}
	return $title;
  }
	 
	 
}

?>