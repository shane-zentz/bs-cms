<?php
  /*
  BS-CMS (c) 2020 by Shane Zentz
  This file outputs all pages of the pages.xml file and gives user options to edit, view, or delete 
  each page listed...
  */
 session_start();

if (!isset($_SESSION['nID']))
{
    header("Location: admin-login.php");
    die();
} 

require_once('activityClass.php');
$act = new Activity();
// insert the post data into variables to be inserted into the node...
$index = $_POST['index'];
$pageName = $_POST['pageName'];
$template = $_POST['Template'];
$metaTitle = $_POST['metaTitle'];
$metaDescription = $_POST['metaDescription'];
$bodyContent = $_POST['bodyContent'];
$pageURL = $_POST['pageUrl'];
$update = false;

//$xml = simplexml_load_file('database/pages.xml');


// load the document
// the root node is so we load it into $info
$file = 'database/pages.xml';

    $xml = new DOMDocument();
    $xml->load($file);

// loop through the nodes to find the correct one to update...
$record = $xml->getElementsByTagName('page');
    foreach ($record as $person) {
		//echo "foreach loops";
        $person_id = $person->getElementsByTagName('index')->item(0)->nodeValue;
        //if we finds the matching node...
        if ($person_id == $index) {
			//echo "founds the matches...";
			// update
			$update = true;
            $person->getElementsByTagName('index')->item(0)->nodeValue = $index;
			$person->getElementsByTagName('pageTitle')->item(0)->nodeValue = $pageName;
			$person->getElementsByTagName('metaTitle')->item(0)->nodeValue = $metaTitle;
			$person->getElementsByTagName('metaDescription')->item(0)->nodeValue = $metaDescription;
			$person->getElementsByTagName('template')->item(0)->nodeValue = $template;
			$person->getElementsByTagName('pageURL')->item(0)->nodeValue = $pageURL;
			$person->getElementsByTagName('bodyContents')->item(0)->nodeValue = base64_encode($bodyContent);
		}
	}



// save the updated document
//$pages->asXML('database/pages.xml');
if ($update){
	//echo 'update = true';
	$xml->save($file);
	$act->addActivity($_SESSION["username"], "Edited Page: ".$pageName);
	header("refresh:2; index.php"); // really should be a fully qualified URI
echo '<script type="text/javascript">alert("Content Edited...");</script>';
}



?>