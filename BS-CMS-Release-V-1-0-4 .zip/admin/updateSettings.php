<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is for updating the settings by the user of the CMS
*/

// get post data sent into variables first:
$siteTitle = $_POST['siteTitle'];                              // site title
$siteFavicon = $_FILES['faviconUpload'];  					            // site favicon
$siteLogo = $_FILES['logoUpload'];                     // site logo
//$siteAdminEmail = $_POST['siteAdminEmail'];  // site admin email
$update = false;                                                  // was the file updated?
//if (isset($_FILES['faviconUpload'])){$uploadFavicon = true;echo 'FAVICON UPLOADED...<br>';} else {$uploadFavicon = false;}
// first get the uploaded favicon and logo into the /uploads/user/settings folder...
//if (isset($_FILES['logoUpload'])){$uploadLogo = true;echo 'LOGO UPLOADED...<br>';} else {$uploadLogo = false;}
$target_dir = "uploads/user/settings/";
$target_file = $target_dir . basename($_FILES["faviconUpload"]["name"]);
$target_file2 = $target_dir . basename($_FILES["logoUpload"]["name"]);
$uploadOk = 1;
$imageFileType = strtolower(pathinfo($target_file,PATHINFO_EXTENSION));
$imageFileType2 = strtolower(pathinfo($target_file2,PATHINFO_EXTENSION));
$uploadFavicon = false;
$uploadLogo = false;

// Check if image file is a actual image or fake image
if(isset($_POST["submit"])) {
	//echo 'SUBMIT IS SET...<br>';
  $check = getimagesize($_FILES["faviconUpload"]["tmp_name"]);
  $check2 = getimagesize($_FILES["logoUpload"]["tmp_name"]);
  if($check !== false) {
	  $uploadFavicon = true;
	  
    echo "File is an image - " . $check["mime"] . ".<br>";
    $uploadOk = 1;
  } else {
    echo "File is not an image.<br>";
    $uploadOk = 0;
  }
  if($check2 !== false) {
	  $uploadLogo = true;
    echo "File is an image - " . $check["mime"] . ".<br>";
    $uploadOk = 1;
  } else {
    echo "File is not an image.<br>";
    $uploadOk = 0;
  }
}

//if ($uploadFavicon == true){echo 'uploadFavicon is true...<br>';}
//if ($uploadLogo == true){echo 'uploadLogo is true...<br>';}

/* Check if file already exists
if (file_exists($target_file)) {
  echo "Sorry, file already exists.";
  $uploadOk = 0;
}
*/
// Check file size
if ($_FILES["faviconUpload"]["size"] > 500000 || $_FILES["logoUpload"]["size"] > 500000) {
  echo "Sorry, your file is too large.<br>";
  $uploadOk = 0;
}



// Allow certain file formats
if($imageFileType != "jpg" && $imageFileType != "png" && $imageFileType != "jpeg"
&& $imageFileType != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br>";
  $uploadOk = 0;
}
// Allow certain file formats
if($imageFileType2 != "jpg" && $imageFileType2 != "png" && $imageFileType2 != "jpeg"
&& $imageFileType2 != "gif" ) {
  echo "Sorry, only JPG, JPEG, PNG & GIF files are allowed.<br>";
  $uploadOk = 0;
}
// Check if $uploadOk is set to 0 by an error
if ($uploadOk == 0) {
  echo "Sorry, your file was not uploaded.<br>";
// if everything is ok, try to upload file
} else {
	
if ($uploadFavicon == true){
  if (move_uploaded_file($_FILES["faviconUpload"]["tmp_name"], $target_file)) {
    echo "The file ". basename( $_FILES["faviconUpload"]["name"]). " has been uploaded.<br>";
} else {
    echo "Sorry, there was an error uploading your file.<br>";
}}
if($uploadLogo == true){
  if (move_uploaded_file($_FILES["logoUpload"]["tmp_name"], $target_file2)) {
    echo "The file ". basename( $_FILES["logoUpload"]["name"]). " has been uploaded.<br>";
  } else {
    echo "Sorry, there was an error uploading your file.<br>";
}}
}

// load the document
$file = 'database/settings.xml';

    $xml = new DOMDocument();
    $xml->load($file);
// update the settings.xml file, used to display info in the admin dashboard
// loop through the nodes to find the correct one to update...
$record = $xml->getElementsByTagName('system');
    foreach ($record as $person) {
		//echo 'entering for loops..<br>';
		  $favicon = $person->getElementsByTagName('siteFavicon')->item(0)->nodeValue;
		  $logo = $person->getElementsByTagName('siteLogo')->item(0)->nodeValue;
		  echo '<br><br><br>FAViCON: '.$favicon.'<br>...LOGO: '.$logo.'...<br><br>';
            $person->getElementsByTagName('siteTitle')->item(0)->nodeValue = $siteTitle;
			if($uploadFavicon){$person->getElementsByTagName('siteFavicon')->item(0)->nodeValue = $target_file;} 
			  //else {$person->getElementsByTagName('siteFavicon')->item(0)->nodeValue = $favicon;}
			if($uploadLogo){$person->getElementsByTagName('siteLogo')->item(0)->nodeValue = $target_file2;}
			 // else {$person->getElementsByTagName('siteLogo')->item(0)->nodeValue = $logo;}
			//$person->getElementsByTagName('siteAdminEmail')->item(0)->nodeValue = $siteAdminEmail;
			$update = true;
	}



// save the updated document
//$pages->asXML('database/pages.xml');
if ($update){
	echo 'update = true';
	$xml->save($file);
	header("refresh:2; index.php"); // really should be a fully qualified URI
echo '<script type="text/javascript">alert("Settings Edited...");</script>';
}

?>