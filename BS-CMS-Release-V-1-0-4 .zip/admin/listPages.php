<h2>Edit Pages:</h2>
 <style>
    .tox-notifications-container {display: none !important;}
	.page-item.active .page-link {background-color:#adbbca !important;}
	.page-link {color:#253546 !important;}
</style>
	  <script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>


<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file lists all the pages from the pages.xml database file...
then the user can edit, view, or delete any of the available pages...
*/
require_once('themeClass.php');
$dir = '../themes';
$themeTest2 = new Theme($dir);
$themeTest2->getTheme($dir);
$temps2 = $themeTest2->getTemplates($dir);

$xml = simplexml_load_file('database/pages.xml');

// get a list of available pages from pages.xml for the select dropdownx
$list = $xml->page;

$output = '';
	$output = '<div class="row"><div class="col-sm">&nbsp;</div><div class="col-sm"><nav aria-label="Page navigation example">
  <ul class="pagination justify-content-center">
    <li class="page-item pag_prev">
      <a class="page-link" href="#" tabindex="-1" aria-disabled="true">Previous</a>
    </li>
    <li class="page-item pag_next">
      <a class="page-link" href="#">Next</a>
    </li>
  </ul>
</nav></div><div class="col-sm">&nbsp;</div></div><div class="row p-3">';
for ($i = 0; $i < count($list); $i++) {
	$output .= '<div class="alert bg-light text-dark p-1 m-2 row w-100 contento"><div class="col-sm"><h5 class="text-left"><strong>'.$list[$i]->pageTitle.'</strong></h5></div>';
	$output .= '<div class="col-sm"><p><a href="'.$list[$i]->pageURL.'" target="_blank" class="btn btn-success btn-sm">View Page</a></p></div>';
	 $output .= '<div class="col-sm"><p><a class="btn btn-primary-edit btn-sm" data-toggle="collapse" href="#collapseExamples'.$i.'" role="button" aria-expanded="false" aria-controls="collapseExamples'.$i.'">Edit Page</a></p></div>';
	 $output .= '<div class="col-sm"><form action="deleteElement.php" method="post"><input type="hidden"  name="deletePage" value="'.$list[$i]->index.'">
	<button type="submit" class="btn btn-danger btn-sm delete" name="action" value="delete" onclick="return confirm("Are you sure?")">Delete Page</button></form>
	</div><br clear="all">';
	
	$output .= '<div class="col-12 collapse alert bg-light text-dark p-2" id="collapseExamples'.$i.'">';
	  // for ($i = 0; $i < count($list); $i++) {
	//if ($list[$i]->index == $index){
	$pageIndex[$i] = $list[$i]->index;
	$pageName[$i] = $list[$i]->pageTitle;
	$template[$i] = $list[$i]->template;
	$metaTitle[$i] = $list[$i]->metaTitle;
	$metaDescription[$i] = $list[$i]->metaDescription;
	$bodyContent[$i] = base64_decode($list[$i]->bodyContents);
	$pageURL[$i] = $list[$i]->pageURL;
	//}
  
//}



$output .= '<form action="editPages.php" method="POST">


<!-- pageName -->
<div class="form-group">
    <input type="hidden"  name="index" value="'.$list[$i]->index.'">
	<input type="text" class="form-control form-control-lg" id="pageName'.$i.'" name="pageName" value="'.$pageName[$i].'" required></div>
	
	
	<!-- Template -->	
<div class="form-group">
<select class="form-control form-control-lg" id="template'.$i.'" name="Template" value="'.$template[$i].'">';
foreach ($temps2 as $temp2){
	$output .= '<option value="'.$temp2.'"';if ($temp2 == $template[$i]) {$output .= 'selected';}
	$output .= '>'.$temp2.'</option>';
}
$output .= '</select>
	</div>
	
	
	
<!-- Meta Title -->	
<div class="form-group">
	<input type="text" class="form-control form-control-lg" id="metaTitle'.$i.'" name="metaTitle" value="'.$metaTitle[$i].'">
	</div>

<!-- Meta Description -->	
<div class="form-group">
	<input type="text" class="form-control form-control-lg" id="metaDescription'.$i.'" name="metaDescription" value="'.$metaDescription[$i].'">
	</div>
	
<!-- Url -->
<div class="form-group">
	<input type="text" class="form-control form-control-lg" id="pageURL'.$i.'" name="pageUrl" value="'.$pageURL[$i].' " required>
	</div>
	
	<!-- tinyMCE edit ---><form method="post">
<textarea id="bodyContent'.$i.'" class="myeditablediv" name="bodyContent">'.$bodyContent[$i].'</textarea>
	  
<div class="form-group mt-4">
	<button type="submit" value="Login" class="btn btn-primary btn-lg mr-2 w-100 buttonHeight">Save</button>
	</div>
</form><br clear="all">';

$output .= '</div></div>';


}
$output .= '</div><br clear="all">';
echo $output;





?>

  <script type="text/javascript">
      
	  var dialogConfig2 = {
        title: "Insert Gallery",
        url: "insertGallery.php",
        buttons: [
          {
            type: "custom",
            name: "insert-and-close",
            text: "Insert and Close",
            primary: true,
            align: "end"
          },
          {
            type: "cancel",
            name: "cancel",
            text: "Close Dialog"
          }
        ],
        width: 600,
        height: 300,
        onAction: function(instance, trigger) {
          instance.sendMessage({
            mceAction: "customInsertAndClose2"
          });
        }
      };
	  
	  
  
  tinymce.init({  selector: 'textarea.myeditablediv',
     plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste imagetools wordcount' ],
  toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | code | link image | customInsertButton2',

  setup: function (editor) {
  editor.ui.registry.addButton('customInsertButton2', {
      text: "Insert Gallery",
            icon: "edit-image",
            onAction: () => {
              _api = editor.windowManager.openUrl(dialogConfig2);
            }
          });
		  editor.addCommand("iframeCommand2", function(ui, value) {
            editor.insertContent(value);
          });
  
  },
    relative_urls : false,
remove_script_host : false,
convert_urls : true,
    images_upload_url: 'postAcceptor.php',
    
    // override default upload handler to simulate successful upload
    images_upload_handler: function (blobInfo, success, failure) {
        var xhr, formData;
      
        xhr = new XMLHttpRequest();
        xhr.withCredentials = false;
        xhr.open('POST', 'postAcceptor.php');
      
        xhr.onload = function() {
            var json;
        
            if (xhr.status != 200) {
                failure('HTTP Error: ' + xhr.status);
                return;
            }
        
            json = JSON.parse(xhr.responseText);
        
            if (!json || typeof json.location != 'string') {
                failure('Invalid JSON: ' + xhr.responseText);
                return;
            }
        
            success(json.location);
        };
      
        formData = new FormData();
        formData.append('file', blobInfo.blob(), blobInfo.filename());
      
        xhr.send(formData);
    },  height:500});
  
</script>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.4/jquery.min.js"></script>
<script language="JavaScript" type="text/javascript">
$(document).ready(function(){
    $("button.delete").click(function(e){
        if(!confirm('Are you sure?')){
            e.preventDefault();
            return false;
        }
        return true;
    });
});
</script>
<script>
$( document ).ready(function() { 
    

    pageSize = 10;
    pagesCount = $(".contento").length;
    var currentPage = 1;
    
    /////////// PREPARE NAV ///////////////
    var nav = '';
    var totalPages = Math.ceil(pagesCount / pageSize);
    for (var s=0; s<totalPages; s++){
        nav += '<li class="numeros page-item"><a class="page-link" href="#">'+(s+1)+'</a></li>';
    }
    $(".pag_prev").after(nav);
    $(".numeros").first().addClass("active");
    //////////////////////////////////////

    showPage = function() {
        $(".contento").hide().each(function(n) {
            if (n >= pageSize * (currentPage - 1) && n < pageSize * currentPage)
                $(this).show();
        });
    }
    showPage();


    $(".pagination li.numeros").click(function() {
        $(".pagination li").removeClass("active");
        $(this).addClass("active");
        currentPage = parseInt($(this).text());
        showPage();
    });

    $(".pagination li.pag_prev").click(function() {
        if($(this).next().is('.active')) return;
        $('.numeros.active').removeClass('active').prev().addClass('active');
        currentPage = currentPage > 1 ? (currentPage-1) : 1;
        showPage();
    });

    $(".pagination li.pag_next").click(function() {
        if($(this).prev().is('.active')) return;
        $('.numeros.active').removeClass('active').next().addClass('active');
        currentPage = currentPage < totalPages ? (currentPage+1) : totalPages;
        showPage();
    });
});
</script>