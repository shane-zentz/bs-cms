  <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li data-target="#myCarousel" data-slide-to="1"></li>
      <li data-target="#myCarousel" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="/themes/Base2/images/banner-1.jpg" alt="example banner 1" />
        <div class="container">
          <div class="carousel-caption text-left">
            <h1>This is your homepage!</h1>
            <p>You should edit this content to make it your own...</p>
            <p><a class="btn btn-lg btn-primary" href="#" role="button">Sign up today</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <img src="/themes/Base2/images/banner-2.jpg" alt="example banner 2" />
        <div class="container">
          <div class="carousel-caption">
            <h1>Homepage Slideshow Example</h1>
            <p>This is the example homepage.php template in the Base2 theme, you should edit it or change it to suit your own needs...</p>
            <p><a class="btn btn-lg btn-primary" href="#" role="button">Learn more</a></p>
          </div>
        </div>
      </div>
      <div class="carousel-item">
        <img src="/themes/Base2/images/banner-3.jpg" alt="example banner 3" />
        <div class="container">
          <div class="carousel-caption text-right">
            <h1>Homepage Example</h1>
            <p>This is just an example of what your homepage could look like, obviously you should edit or modify or change it altoghter to meet your needs...</p>
            <p><a class="btn btn-lg btn-primary" href="#" role="button">Browse gallery</a></p>
          </div>
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#myCarousel" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#myCarousel" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

<!-- Start the main container -->
<div class="container-fluid" id="main">
  <!-- start main row -->
  <div class="row">
    <!-- start main col -->
	<div class="col">