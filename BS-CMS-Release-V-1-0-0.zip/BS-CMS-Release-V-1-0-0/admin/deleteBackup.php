<?php
// BS-CMS (c) 2020 by Shane Zentz
// deleteBackup.php
// just delete the selected backup zip file


if (isset($_POST['insert'])&& isset($_POST['fileName'])) {
	$fileToDelete = '../backups/'.$_POST['fileName'];
			unlink($fileToDelete);
		}
		
header("refresh:2; index.php"); // really should be a fully qualified URI
echo '<script type="text/javascript">alert("Backup File Deleted ...");</script>';

?>