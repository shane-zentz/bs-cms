<?php session_start();

if (!isset($_SESSION['nID']))
{
    header("Location: admin-login.php");
    die();
} ?>
<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="Admin Area">
    <meta name="author" content="Shane Zentz">
	
    <!-- Favicon -->
	<link rel="shortcut icon" type="image/x-icon" href="images/favicon.png">

    <title>Admin Area</title>

    <link rel="canonical" href="">

    <!-- Bootstrap core CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	
	

    <!-- Custom styles for this template -->
	<style>
	body {background-color:#091e33 !important;
	      color:white !important;}
	.starter-template {padding-top:30px;}
	#adminLink {background-color:#1b2f42;min-height:800px; padding: 0;}
	.linkMain {display:block;width:100%;text-align:left;color:white;padding:20px }
.linkMain:hover {background-color:#091e33;color:white;font-weight:bold}
.btn-logout {color: #283642;background-color: #FFF;border-color: #EEE;}
.btn-logout:hover {color: #FFF;background-color: #FF0000;border-color: #EEE;}
.btn-primary {background-color:#1a314a !important;border-color:#1a314a !important;}
.btn-primary-edit {background-color: #ff7600; border-color: #ff3b00; color:#fff;}
.btn-primary-edit:hover {background-color:#ff3b00;color:#fff !important;}
input[type=checkbox], input[type=radio] {width:30px;height:25px;}
.form-check-input {margin-left:-2.25rem !important;}
.form-check-label {font-weight:bold;color: darkslategray;}
input:checked ~ .form-check-label {color:green;}
.navbar {background-color:#081727;}
.col-sm{padding:0 !important;}
	</style>
  </head>

  <body>
    <nav class="navbar navbar-expand-md navbar-dark fixed-top">
      <a class="navbar-brand" href="/">BS-CMS</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarsExampleDefault" aria-controls="navbarsExampleDefault" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarsExampleDefault">
	   <div class="col w-100"><h5 class="text-center">Welcome, <?php echo $_SESSION['username']; ?></h5></div>
        <ul class="navbar-nav mr-auto">
        </ul>
        <form class="form-inline my-2 my-lg-0">
			<a href="admin-login.php"><button type="button" class="btn btn-logout">Log Out!</button></a>
        </form>
      </div>
    </nav>

    <main role="main" class="container-fluid">
<br clear="all">
      <div class="starter-template">
	  
	  <div class="row">
	  
	  <!-- left sidebar for admin linx -->
	  <div class="col" id="adminLink" role="tablist">
	          <h3 class="text-center p-2">Admin Area:</h3>
	     <ul class="nav flex-column">
          <li class="nav-itemn border-top  border-light">
            <a class="nav-link active linkMain text-center" data-toggle="tab" role="tab" href="#nav-dashboard" aria-controls="nav-dashboard" aria-selected="true">Dashboard</a>
          </li>
          <li class="nav-item border-top  border-light">
            <a class="nav-link linkMain text-center" data-toggle="collapse" role="tab" href="#collapseExample2" aria-controls="nav-pages" aria-expanded="false">Pages <span style="font-size:20px;font-weight:bolder"><strong> <sub style="font-size:100% !important">&darr;</sub></strong></span></a>
          </li>
		  <ul class="collapse" id="collapseExample2">
		     <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-pages" aria-controls="nav-pages" aria-selected="false">Create a Page</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-pages-list" aria-controls="nav-pages-list" aria-selected="false">Edit/Delete Pages</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-output" aria-controls="nav-output" aria-selected="false">Display All Pages</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-human-sitemap" aria-controls="nav-human-sitemap" aria-selected="false">Human Sitemap</a></li>
		   </ul>
		 <li class="nav-item border-top  border-light">
            <a class="nav-link linkMain text-center"  data-toggle="tab" role="tab" href="#nav-themes" aria-controls="nav-themes" aria-selected="false">Themes</a>
         </li>
		 <li class="nav-item border-top border-light">
            <a class="nav-link linkMain text-center"  data-toggle="tab" role="tab" href="#nav-menu" aria-controls="nav-menu" aria-selected="false">Menu</a>
         </li>
         <li class="nav-item border-top border-bottom border-light">
            <a class="nav-link linkMain text-center" data-toggle="collapse" role="tab" href="#collapseExample3" aria-controls="nav-settings" aria-expanded="false">System <span style="font-size:20px;font-weight:bolder""><strong> <sub style="font-size:100% !important">&darr;</sub></strong></span></a>
         </li>
		 <ul class="collapse" id="collapseExample3">
		     <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-about" aria-controls="nav-about" aria-selected="false">About</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-settings" aria-controls="nav-settings" aria-selected="false">Settings</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-users" aria-controls="nav-users" aria-selected="false">Users</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-addon" aria-controls="nav-addon" aria-selected="false">Add-Ons</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-backup" aria-controls="nav-backup" aria-selected="false">Backup</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-activity" aria-controls="nav-activity" aria-selected="false">Activity Logs</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="" 
  target="popup" 
  onclick="window.open('https://maquinadenoticias.000webhostapp.com/phpson/admin/visitors.php','popup','width=600,height=600,scrollbars=no,resizable=no'); return false;" aria-controls="nav-visitor" aria-selected="false">Visitor Logs</a></li>
			 <li class="nav-item"><a class="nav-link linkMain" data-toggle="tab" role="tab" href="#nav-help" aria-controls="nav-help" aria-selected="false">Help</a></li>
			</ul>
		</ul>
	  </div>
	  <!-- main content area for admin area -->
	  <div class="col-10">
	  		  
		  <!-- nav/tab centent-->
		  <div class="tab-content" id="nav-tabContent">
           <div class="tab-pane fade show active" id="nav-dashboard" role="tabpanel" aria-labelledby="nav-dashboard-tab"><?php require_once('dashboard.php');?></div>
		   <div class="tab-pane fade" id="nav-pages" role="tabpanel" aria-labelledby="nav-pages-tab"><?php require_once('page.php');?></div>
		   <div class="tab-pane fade" id="nav-pages-list" role="tabpanel" aria-labelledby="nav-pages-list-tab"><?php require_once('listPages.php');?></div>
		   <div class="tab-pane fade" id="nav-output" role="tabpanel" aria-labelledby="nav-output-tab"><h2>Output</h2><?php require_once('output.php');?></div>
		   <div class="tab-pane fade" id="nav-human-sitemap" role="tabpanel" aria-labelledby="nav-human-sitemap-tab"><?php require_once('humanSitemap.php');?></div>
		   <div class="tab-pane fade" id="nav-addon" role="tabpanel" aria-labelledby="nav-addon-tab"><?php require_once('addon.php');?></div>
		   <div class="tab-pane fade" id="nav-themes" role="tabpanel" aria-labelledby="nav-themes-tab"><?php require_once('themes.php');?></div>
		   <div class="tab-pane fade" id="nav-menu" role="tabpanel" aria-labelledby="nav-menu-tab"><?php require_once('menus.php');?></div>
		   <div class="tab-pane fade" id="nav-users" role="tabpanel" aria-labelledby="nav-users-tab"><h2>Users</h2><?php require_once('users.php');?></div>
		   <div class="tab-pane fade" id="nav-settings" role="tabpanel" aria-labelledby="nav-settings"><h2 class="text-center">Settings</h2><?php require_once('settings.php');?></div>
		   <div class="tab-pane fade" id="nav-about" role="tabpanel" aria-labelledby="nav-about-tab"><?php require_once('about.php');?></div>
		   <div class="tab-pane fade" id="nav-help" role="tabpanel" aria-labelledby="nav-help-tab"><?php require_once('help.php');?></div>
		   <div class="tab-pane fade" id="nav-backup" role="tabpanel" aria-labelledby="nav-backups-tab"><?php require_once('backups.php');?></div>
		   <div class="tab-pane fade" id="nav-activity" role="tabpanel" aria-labelledby="nav-activity-tab"><?php require_once('activity.php');?></div>
		   
		  </div><!-- end nav/tab content-->
		  
      </div>
	  </div>


    </main><!-- /.container -->

    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
<script src="js/jquery.nestable.js"></script>
<!-- the scripts below are a hack to fix bootstrap problem of it adds class active to nav item in sidebar (with nav panel)
     and then does not remove the active class when something else is clicked, so that any sub menu item in sidebar can 
	 only be clicked once, then the page will need to be refreshed in order to click on the link again, this hack just 
	 removes the active classes altogether.. maybe this hack wont be necessary in future versions of bootstrap ? -->
<script>$(document).ready(function() {
	   $('#collapseExample a').click(function (e) {
   e.preventDefault();
   $(this).removeClass('active');
}); 
$('#collapseExample2 a').click(function (e) {
   e.preventDefault();
   $(this).removeClass('active');
}); 
$('#collapseExample3 a').click(function (e) {
   e.preventDefault();
   $(this).removeClass('active');
}); 

 var updateOutput = function(e)
    {
        var list   = e.length ? e : $(e.target),
            output = list.data('output');
        if (window.JSON) {
            output.val(window.JSON.stringify(list.nestable('serialize')));//, null, 2));
        } else {
            output.val('JSON browser support required for this demo.');
        }
    };

    // activate Nestable for list 1
    $('#nestable').nestable({
        group: 1
    })
    .on('change', updateOutput);

    // activate Nestable for list 2
    $('#nestable2').nestable({
        group: 1
    })
    .on('change', updateOutput);

    // output initial serialised data
    updateOutput($('#nestable').data('output', $('#nestable-output')));
    updateOutput($('#nestable2').data('output', $('#nestable2-output')));

    $('#nestable-menu').on('click', function(e)
    {
        var target = $(e.target),
            action = target.data('action');
        if (action === 'expand-all') {
            $('.dd').nestable('expandAll');
        }
        if (action === 'collapse-all') {
            $('.dd').nestable('collapseAll');
        }
    });
    $('#addCustom').on('click', function(e)
    {
var name = document.getElementById("customName").value;
	var url = document.getElementById("customURL").value;
	var id = 5000;
	var ul = document.getElementById("nestable");
  var li = document.createElement("li");
  //li.appendChild(document.createTextNode(name));
  li.setAttribute("class", "dd-item"); // added line
  li.setAttribute("data-id",name);
  li.setAttribute("data-url",url);
   var div = document.createElement("div");
  div.appendChild(document.createTextNode(name));
  div.appendChild(document.createTextNode("   /  "));
  div.appendChild(document.createTextNode(url));
  div.setAttribute("class", "dd-handle"); // added line
  li.appendChild(div);
  ul.appendChild(li);
  });
});</script>
  </body>
</html>