<h2>Create Page</h2>
<script src="https://cdn.tiny.cloud/1/no-api-key/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<style>
    .tox-notifications-container {display: none !important;}
</style>
<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is the page for creating a new page within BS-CMS
using the form entries and the tinyMCEs editor...
*/
include 'themeClass.php';
$dir = '../themes';
$themesTest = new Theme($dir);
$themesTest->getTheme($dir);
$temps = $themesTest->getTemplates($dir);
$outs = '';

$outs .= '<form action="addContent.php" method="POST">
<!-- pageName -->
<div class="form-group">
	<input type="text" class="form-control form-control-lg" name="pageName" placeholder="Pagename" required></div>

<!-- Template -->	
<div class="form-group">
<select class="form-control form-control-lg" name="Template" placeholder="Template">
 <option value="" selected disabled hidden>Choose Template</option>';
foreach ($temps as $temp){
	$outs .= '<option value="'.$temp.'">'.$temp.'</option>';
}
$outs .= '</select>
	</div>
	
<!-- Meta Title -->	
<div class="form-group">
	<input type="text" class="form-control form-control-lg" name="metaTitle" placeholder="Meta Title">
	</div>

<!-- Meta Description -->	
<div class="form-group">
	<input type="text" class="form-control form-control-lg" name="metaDescription" placeholder="Meta Description">
	</div>
	
<!-- Url -->
<div class="form-group">
	<input type="text" class="form-control form-control-lg" name="pageUrl" placeholder="Page URL" required>
	</div>
	
<!-- tinyMCE edit -->
<textarea id="pageBody" class="myeditablediv" name="pageBody"></textarea>
	  
<div class="form-group mt-4">
	<button type="submit" value="Login" class="btn btn-primary btn-lg mr-2 w-100 buttonHeight">Post</button>
	</div>
</form><br clear=\"all\">';

echo $outs;

?>


  <script type="text/javascript">
  
	  var dialogConfig42 = {
        title: "Insert Gallery",
        url: "insertGallery.php",
        buttons: [
          {
            type: "custom",
            name: "insert-and-close",
            text: "Insert and Close",
            primary: true,
            align: "end"
          },
          {
            type: "cancel",
            name: "cancel",
            text: "Close Dialog"
          }
        ],
        width: 600,
        height: 300,
        onAction: function(instance, trigger) {
          instance.sendMessage({
            mceAction: "customInsertAndClose2"
          });
        }
      };
  
  tinymce.init({selector:'textarea.myeditablediv',  plugins: [
    'advlist autolink lists link image charmap print preview anchor',
    'searchreplace visualblocks code fullscreen',
    'insertdatetime media table paste imagetools wordcount' ],
  toolbar: 'insertfile undo redo | styleselect | bold italic | alignleft aligncenter alignright alignjustify | bullist numlist outdent indent | code | link image | customInsertButton22',

  setup: function (editor) {
  editor.ui.registry.addButton('customInsertButton22', {
      text: "Insert Gallery",
            icon: "edit-image",
            onAction: () => {
              _api = editor.windowManager.openUrl(dialogConfig42);
            }
          });
		  editor.addCommand("iframeCommand2", function(ui, value) {
            editor.insertContent(value);
          });
  
  },
  relative_urls : false,
  remove_script_host : false,
  convert_urls : true,
  //document_base_url : "/",
    images_upload_url: 'postAcceptor.php',
	images_upload_base_path: '/uploads/user',
    
    // override default upload handler to simulate successful upload
    images_upload_handler: function (blobInfo, success, failure) {
        var xhr, formData;
      
        xhr = new XMLHttpRequest();
        xhr.withCredentials = false;
        xhr.open('POST', 'postAcceptor.php');
      
        xhr.onload = function() {
            var json;
        
            if (xhr.status != 200) {
                failure('HTTP Error: ' + xhr.status);
                return;
            }
        
            json = JSON.parse(xhr.responseText);
        
            if (!json || typeof json.location != 'string') {
                failure('Invalid JSON: ' + xhr.responseText);
                return;
            }
        
            success(json.location);
        };
      
        formData = new FormData();
        formData.append('file', blobInfo.blob(), blobInfo.filename());
      
        xhr.send(formData);
    },  height:500});
  //console.log("inited.....");
</script>


  
 