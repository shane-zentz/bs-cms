<?php
/*
BS-CMS (c) 2020 by Shane Zentz
this file just outputs some code to be used for a human readable sitemap..
*/
require 'sitemapClass.php';

echo '<h2>Human Readable Sitemap</h2><p>To add a human readable sitemap to your website, simply copy and paste the code below into a new page (under Pages->Create Page) and Publish. Remember to update the page with new code from this tab whenever a new page is added or an old page is deleted.</p><br><small>Note: in a future release of this CMS we would like to add an automatic human readable sitemap that is automatically created and added (similar to the sitemap.xml), so check back for updates...</small><br><br>';

$sitemap = new Sitemap();

$sitemap->generateHumanSitemap();

?>