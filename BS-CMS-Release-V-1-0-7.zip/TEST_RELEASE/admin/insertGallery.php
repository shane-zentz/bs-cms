
  <form action="" method="post" multipart="" enctype="multipart/form-data">
	 <div class="form-group">
	
	<input type="text" class="form-control form-control-lg" name="galleryTitle" placeholder="Gallery Title"></div>
   <div class="form-group">
	   <input type="file" class="form-control form-control-lg" name="img[]" multiple></div>
	 <div class="form-group">
        <button type="submit" class="btn btn-primary btn-lg mr-2 w-100 buttonHeight">Submit</button>
    </div>
</form><br clear="all">
<h3>Instructions:</h3>
<ul>
  <li>1. Give the gallery a title (if desired)</li>
  <li>2. click 'Choose Files', select multiple files</li>
  <li>3. click 'submit' and then click 'Insert and Close'</li>
</ul>

<?php
			error_reporting(0);
			
function reArrayFiles($file)
{
    $file_ary = array();
    $file_count = count($file['name']);
    $file_key = array_keys($file);
   
    for($i=0;$i<$file_count;$i++)
    {
        foreach($file_key as $val)
        {
            $file_ary[$i][$val] = $file[$val][$i];
        }
    }
    return $file_ary;
}

$img = $_FILES['img'];
$title = $_POST["galleryTitle"];
//echo "Gallery title is: ".$title."<br>";
$run = 0;

if (empty($title)){$newDirname = date('YmdHis',time()).mt_rand();}
if (!empty ($title)) {$newDirname = $title;}
if(!empty($img) )
{
    $img_desc = reArrayFiles($img);
	//echo "The following files have been uploaded. ";
    //print_r($img_desc);
   
	//$newDirname = date('YmdHis',time()).mt_rand();
	 //$newDirname = $title;
	 
	 /* FIRST NEED TO MAKE SURE DIRECTORY DOESNT ALREADY EXIST, IF IT DOES INFORM USER TO GO BACK AND TRY AGAIN */
	  if (!file_exists( '../uploads/'.$title ) && !is_dir( '../uploads/'.$title ) ) {
		if ($newDir = mkdir('../uploads/'.$newDirname.'/', 0777, true))
		{
		  $newDirPath = '../uploads/'.$newDirname;
		  //echo "<h1>Folder Path: ".$newDirPath."</h1>";
		  chmod('../uploads/',0777);
	      chmod($newDirPath,0777);
		
		}
		}
}

// first run
else if ($run == 0) {//do nutin
}
		// not pretty but it works yo...
		else { //echo "Directory already exists... Please go back and try again with new Gallery Title!"; 
		?>
		<script type = 'text/javascript'>
//<!--
   alert("Directory already exists... Please go back and try again with new Gallery Title!");
//-->
</script>
		<?php
		return;
		}
 

$outHTML = '<div class=\"row p-3\"><div class=\"col-12 p-5\"><h2>'.$title.' Gallery</h2>';
    foreach($img_desc as $val)
    {
       //$newname = date('YmdHis',time()).mt_rand().'.jpg';
	   $outname = $newDirPath.'/'.$val['name'];
		$outHTML .= '<a  class=\"example-image-link\" href=\"'.$outname.'\" data-lightbox=\"example\"><img src=\"'.$outname.'\"  style=\"width:150px !important; height:104px !important;\" alt=\"\" /></a>';
	    //echo '<h5>'.$val['name'].'</h5><br>';
        move_uploaded_file($val['tmp_name'], $newDirPath.'/'.$val['name']);
		//move_uploaded_file($val['tmp_name'], $newDir);
    }
	
$outHTML .= '</div>';
//return $outHTML;
?>
<script>console.log('end of php code...');</script>

<?php

?>

<script>
console.log('getting to script');
  var returnVal = '<?php echo $outHTML; ?>';
  window.addEventListener('message', function (event) {
    console.log(event.data)
    if (event.data.mceAction ==='customInsertAndClose2'){
	console.log('var is set');
      var value = returnVal;

       console.log(value);
      window.parent.postMessage({
        mceAction: 'execCommand',
        cmd: 'iframeCommand2',
        value 
      }, origin);

      window.parent.postMessage({
            mceAction: 'close'
        }, origin);
    }
  });

</script>