<?php
require 'activityClass.php';

$acts = new Activity();
$acts->clearActivity();

?>