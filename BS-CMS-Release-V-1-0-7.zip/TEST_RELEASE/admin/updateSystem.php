<?php
  /* File: updateSystem.php - a file used to call the update system function of the update cms class...
                            - if this file is called, then it means we must update
     Author: Shane Zentz 2021
  */
    include('updateCLASS.php');
    $update = new updateCMS();
	$update->updateSystem();
?>