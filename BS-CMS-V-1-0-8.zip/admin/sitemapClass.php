<?php
/*
Class: Sitemap
Author: Shane Zentz 2020
Desc: This class creates the sitemap for all pages in the cms/website.

*/
class Sitemap{

 // constructor
  public function __construct() { 
  //echo 'new sitemap object...<br>'; 
  }
  
 public function generateHumanSitemap(){
   $xml = simplexml_load_file('database/pages.xml');
   $list = $xml->page;
   $filename = '../humanSitemap.txt';
   $host = sprintf(
    "%s://%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['HTTP_HOST']);
   //echo htmlspecialchars('<h2>Sitemap</h2><ul>', ENT_QUOTES);
   $outputs = '<h2>Sitemap</h2><ul>';
   for ($i = 0; $i < count($list); $i++) {
	   if ($list[$i]->pageURL != "/") {
	   //echo htmlspecialchars('<li><a href="'.$host.$list[$i]->pageURL.'">'.$list[$i]->pageTitle.'</a></li>', ENT_QUOTES);
	   $outputs .= '<li><a href="'.$host.$list[$i]->pageURL.'">'.$list[$i]->pageTitle.'</a></li>';
   }}
   //echo htmlspecialchars('</ul>', ENT_QUOTES);
   $outputs .= '</ul>';
   
   // write the outputs to a file...
   file_put_contents($filename, $outputs, LOCK_EX);
 }
  
 // create the sitemap...
 public function generateSitemap () {
	 //echo 'calling generateSitemap...<br>';
   // frist step, open the main pages.xml file to get the links and page names

  $file = '../sitemap.xml';
   $xml = simplexml_load_file('database/pages.xml');
   $xml2 = simplexml_load_file($file);
   
 // echo 'XML: '.var_dump($xml).'<br>';
 // echo 'XML2: '.var_dump($xml2).'<br>';
  
  // empty the current sitemap.xml file url elements,,,,
 while($xml2->url) { unset($xml2->url); } 

$xml2->asXML($file);
//echo '<br><br><br>after : XML2: '.var_dump($xml2).'<br><br><br>';
   // get a list of available pages from pages.xml for the select dropdownx
   $list = $xml->page;
   

  /* $baseURL = sprintf(
    "%s://%s%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http',
    $_SERVER['SERVER_NAME'],
    $_SERVER['REQUEST_URI']
  );*/
  
  $host = sprintf(
    "%s://%s",
    isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] != 'off' ? 'https' : 'http', $_SERVER['HTTP_HOST']);
    //echo $baseURL;
	$baseURL2 = str_replace('admin/sitemapTest.php',"",$baseURL);
	//echo '<br><br>Real Base URl: '.$baseURL2;
	
	$baseURL2NS = rtrim( $baseURL2, '/' );
   
   // then go through the pages.xml file, and first find the homepage
   // and then get all subsequent pages, add all to an array,
   
   //$output = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">';
   
    $urls = array();
	//array_push($urls, $output);
   
   for ($i = 0; $i < count($list); $i++) {
	   if ($list[$i]->pageURL != "/") {
	   //echo $list[$i]->pageURL.'<br>';
	   // get the list of urls into an array to write to sitemap.xml laters...
	   array_push($urls,(string)$list[$i]->pageURL);
   }}
   //array_push($urls, '</urlset>');
   //echo '<br><br>';
   //print_r($urls);
   
   // add the default homepage first...
   $entry = $xml2->addChild('url');
   $entry->addChild('loc', $host);
   
   foreach ($urls as $key){

	 $entry = $xml2->addChild('url');
    $entry->addChild('loc', $host .''. $key);

   }
   
   
   
   $domxml = new DOMDocument('1.0');
$domxml->preserveWhiteSpace = false;
$domxml->formatOutput = true;
/* @var $xml SimpleXMLElement */
$domxml->loadXML($xml2->asXML());
$domxml->save($file);


	  $fileStart = '<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9" xmlns:xhtml="http:www.w3.org/1999/xhtml">';

 }
}
?>