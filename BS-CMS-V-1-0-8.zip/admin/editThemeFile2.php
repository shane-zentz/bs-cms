<?php
echo '<h1>Editing Theme File: '.$_POST['themeDirFile'].'</h1>'; // the theme name:
$themeFile = $_POST['themeDirFile'];
echo '<br>';
//echo 'Theme file data variable: '.$_POST['themeFileData'];
$addContents = $_POST['themeFileData'];
$addContents2 = htmlspecialchars($_POST['themeFileData']);
echo '<br>HTML SPECIAL CHARS: '.$addContents2;


// next try to write the file...
if(file_exists($themeFile)){
                if (!empty($addContents)) {
           file_put_contents($themeFile, $addContents);
			     
        //header("reload:2"); // really should be a fully qualified URI
			  echo '<script type="text/javascript">alert("Theme File Edited...\n Please close this window");window.close();</script>
';
			     
}
else {echo '<script type="text/javascript">alert("File Contents Empty?");</script>';}

}
	else {
		header("refresh:2"); // really should be a fully qualified URI
			  echo '<script type="text/javascript">alert("File does not exist...");</script>';
	}


?>