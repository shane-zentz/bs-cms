<?php

$dir = '../themes/'.$_GET['themeFileName'].'/templates/';
echo '<h1 class="text-center">Create a new template file for theme: '.$dir.'</h1>';
	
	
// just some style for this page:
echo '<style>
body{
background-color: #091e33 !important;
color: white !important;
}
.text-center {position:relative;margin: 0 auto; text-align:center;}
</style>';
	

// it's missing the .. , so add it in, justin case...
//$themeFileName = '..'.$_GET['themeFileName'];
//echo '<h1 class="text-center">Editing Theme File: '.$themeFileName;

// echo out the empty/blank textarea
echo '<div class="text-center"><form id="createTemplateFile" method="post" action="addTemplateFile2.php">
                              File Name: <input type="text" name="templateFileName" value=""><br/>
							  <input type="text" name="themeDir" value="'.$dir.'" hidden><br>
                              <textarea rows="16" cols="100" name="templateFileContents"></textarea><br/>
                              <input type="submit" form="createTemplateFile" name="submitsave1" value="Create Tempate File">
                      </form></div>';
	
	
?>