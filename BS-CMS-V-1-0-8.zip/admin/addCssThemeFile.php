<?php

$dir = '../themes/'.$_GET['themeFileName'].'/css/';
echo '<h1 class="text-center">Create a new CSS file for theme: '.$dir.'</h1>';
	
	
// just some style for this page:
echo '<style>
body{
background-color: #091e33 !important;
color: white !important;
}
.text-center {position:relative;margin: 0 auto; text-align:center;}
</style>';
	

// it's missing the .. , so add it in, justin case...
//$themeFileName = '..'.$_GET['themeFileName'];
//echo '<h1 class="text-center">Editing Theme File: '.$themeFileName;

// echo out the empty/blank textarea
echo '<div class="text-center"><form id="createCssFile" method="post" action="addCssThemeFile2.php">
                              File Name: <input type="text" name="cssFileName" value=""><br/>
							  <input type="text" name="themeDir" value="'.$dir.'" hidden><br>
                              <textarea rows="16" cols="100" name="cssFileContents"></textarea><br/>
                              <input type="submit" form="createCssFile" name="submitsave1" value="Create CSS File">
                      </form></div>';
	
	
	
?>