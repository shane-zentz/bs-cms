<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is the form for updating basic settings (site title, favicon, logo, etc.
which should already be set when the system is installed...
*/
$xml = simplexml_load_file('database/settings.xml');

// get a the system xml file
$list = $xml->system;

$output = '';
	//$output = '<div class="row p-3">';
for ($i = 0; $i < count($list); $i++) {
  $output .= '<form action="updateSettings.php" method="post" enctype="multipart/form-data">
	 <div class="form-group"><h5>Site Title</h5>
	   <input type="text" class="form-control form-control-lg" name="siteTitle" value="'.$list[$i]->siteTitle.'" required>
	   <small id="formDesc" class="form-text">Please enter your sites title or slogan.</small>
	 </div>
	 <div class="form-group"><h5>Favicon</h5>
	   <input type="file" name="faviconUpload" id="faviconUpload" >
	   <small id="formDesc" class="form-text">Please upload your sites favicon (32px x 32px)</small>
	   <div><img class="float-img-right" style="width:32px;height:32px" alt="favicon" src="'.$list[$i]->siteFavicon.'" /></div>
	 </div>
	 <!--<div class="form-group">
	   <input type="text" class="form-control form-control-lg" name="siteAdmin" value="'.$list[$i]->siteAdmin.'" required>
	   <small id="formDesc" class="form-text">Please enter your sites Admin name.</small>
	 </div>-->
	 <div class="form-group"><h5>Site Logo</h5>
	   <input type="file" name="logoUpload" id="logoUpload" >
	   <small id="formDesc" class="form-text">Please upload your websites logo. Best size is under 300px x 300px.</small>
	   <div><img class="float-img-right" style="width:300px;height:300px;" alt="logo" src="'.$list[$i]->siteLogo.'" /></div>
	 </div>
	 
	 <div class="form-group">
        <button type="submit" name="submit" class="btn btn-primary btn-lg mr-2 w-100 buttonHeight">Save Settings</button>
    </div>
</form><br clear="all">';
}
echo $output;
?>