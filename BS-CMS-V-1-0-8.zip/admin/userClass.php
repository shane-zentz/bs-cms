<?php
/*
Class: User
Author: Shane Zentz
Date: 2020
Desc: This class defines a user of the CMS system. Methods are included to create a new user, update an existing user,

*/

class User {
	
// the user
protected $user = '';
// the password for the current user
protected $pass = '';
// the users file, a json file that contains users and their passwords (in md5 format)...
protected $userFile = '../admin/login.json';
protected $userFile2 = 'login.json';

public function __construct()
{
}


// method to create a new user...
// returns true on user createion
public function createUser ($user, $pass){
	 $read = file_get_contents($this->userFile);
	 //var_dump($read);
	 $reads = json_decode($read, true);
	 $success = false;
	 
	 // make sure user doesn't already exists...
	 if ($this->doesUserExist ($user)){header("refresh:2; index.php"); // really should be a fully qualified URI
echo '<script type="text/javascript">alert("User already exists...");</script>';}
	 else {
	 //var_dump($reads);
	 //$data = array();
	 $data = '{ 
      "User":"'.$user.'",
      "Password":"'.password_hash($pass, PASSWORD_BCRYPT).'"
   }';
     $dataJson = json_decode($data);
	 array_push($reads, $dataJson);
     $jsonData = json_encode($reads);
     file_put_contents($this->userFile, $jsonData);
	 $success = true;
	 }
	 return $success;
}

// method to create the first user...
// returns true on user createion
public function createFirstUser ($user, $pass){
	 $read = file_get_contents($this->userFile2);
	 //var_dump($read);
	 $reads = json_decode($read, true);
	 $success = false;
	 
	 
	 //var_dump($reads);
	 //$data = array();
	 $data = '{ 
      "User":"'.$user.'",
      "Password":"'.password_hash($pass, PASSWORD_BCRYPT).'"
   }';
     $dataJson = json_decode($data);
	 array_push($reads, $dataJson);
     $jsonData = json_encode($reads);
     file_put_contents($this->userFile2, $jsonData);
	 $success = true;
	 
	 return $success;
}

//method to update an existing user, typically just update an existing
// users password....
// returns true on successful update, false otherwise (user doesnt exist)...
public function updateUser ($user, $pass){
	
	$out = false;
	// first make sure the user really exists...
	if (!$this->doesUserExist($user)) { $out = false; exit(0); }
	// if the user really does exist, find their entry in the userFile and update password...
	else {
	 //$acts = new Activity();
	 $read = file_get_contents($this->userFile);
	 $reads = json_decode($read, true);
	 //var_dump($reads);
	
	foreach ($reads as &$key) {
		//echo "KEY: ".$key."<br>VAl: ".$val."<br>";
	if ($key['User'] == $user) {
		//echo '<br><br>User is Matched...<br><br>';
		$key['Password'] = password_hash($pass, PASSWORD_BCRYPT);
		//echo '<br>$key->password: '.$key['Password'].'<br>';
		$out = true;
	}
    }
	$jsonData = json_encode($reads);
        file_put_contents($this->userFile, $jsonData);
    return $out;
	}
}

// method to find if a user exists in the $userFile
// returns true if user is found in file, false if not found...
public function doesUserExist ($user){
	$userExists = false;
	
	 $read = file_get_contents($this->userFile);
	 $reads = json_decode($read, true);
	  
	 $jsonIterator = new RecursiveIteratorIterator(
    new RecursiveArrayIterator($reads,
    RecursiveIteratorIterator::SELF_FIRST));
	
	foreach ($jsonIterator as $key => $val) {
		//echo "KEY: ".$key."<br>VAl: ".$val."<br>";
	if ($key == 'User' && $val == $user) {
        $userExists = true;
    }		
}
return $userExists;
}

// method to get all users from the users file
// this is used for the Users admin panel page ... returns array of users file
public function getAllUsers(){
	$read = file_get_contents($this->userFile);
	 $reads = json_decode($read, true);
	 // just return the raw array with all data...
	  return $reads;
}

}
?>