<?php
/*
Class Theme
BS-CMS
Shane Zentz 2020
desc: this is the class for theme objects, main object is an array with each object in the array being theme
      name, description, URI, author name, image, directory (folder), and whether or not the theme is the 
	  active theme...
	  Methods are included to build out the Themes page in the admin panel, as well as methods to build the
	  themes array, find out if the theme is the active theme, and to find out if a theme is a valid theme
	  (so it should be included in theme list or not), and return parts of the theme (such as header, footer)...
*/
class Theme{
  // array of all themes found in directory
  protected $themes = array();
  protected $themeDir;
  protected $outs = array();
  protected $activeThemeFile = "../admin/database/activeTheme.xml";
  protected $activeThemeFile2 = "admin/database/activeTheme.xml";
  protected $currentActiveTheme = "";  // variable to keep the current active theme.... set in the getCurrentActiveTheme method
  
  
  /* empty constructor / init for the themesetActive form submit
  public function __(){
  }*/
  
  public function __construct($themeDir)
  {
	  $this->themeDir = $themeDir;
	  //echo 'loading theme class...';
  }
  
  public function themeArrayTest(){
	  	  echo '<br>calling themearraytest...<br>';
	  $themeArray = $this->themes;
	 // print_r($themeArray);
	 return $themeArray;
  }


  public function themesList($themeName, $themeDir, $themeDesc, $themeURI, $themeAuthor, $themeImage, $isThemeActive ){
    array_push(self::$themes,Array(
      'name' => $themeName,
	  'directory' => $themeDir,
      'description' => $themeDesc,
      'uri' => $themeURI,
	  'author' => $themeAuthor,
	  'image' => $themeImage,
	  'activeTheme' => $isThemeActive
    ));
  }
  
  // get the necessary components of the theme to make the themes.php file for the admin area
  // needs to get only theme name, description, uri, author, image, and find out if it is theme
  // active theme or no
  public function getTheme($themeDir){
	 // echo '<br>calling getTheme....<br>';
  // call the scanDirectories method to gets a list of all $dir/theme.xml files 
  //$dire = $this->themeDir;
  $themeXmlFiles = Array();
  $themeXmlFiles = $this->scanDirectories($themeDir);
 //echo '<br>themeXmlFiles var dump: '; var_dump($themeXmlFiles); //working
			foreach($themeXmlFiles as $file){
				//echo '<br>entering first for loops<br>';
				// we needs to find first the theme.xml file for each theme...
                 // echo '<br>file: '.$file.'<br>';
				  $fileRemove = 'theme.xml';
				  $currentThemeFolder = str_replace($fileRemove, '', $file);
				 // echo 'current theme folder: '.$currentThemeFolder;
				  //echo '<br>FOPEN VAL...'.var_dump(ini_get('allow_url_fopen')).'<br><br>...'; 
					$xml = simplexml_load_file($file) or die('files not loaded');
					//var_dump($xml, $http_response_header);
					
					//echo '<br>result of simp xml call: '.var_dump($xml).'<br>'; // SEEMS TO BE //WORKING UP TO HERE>>>>
					$list = $xml->theme;
					//echo '<br>var dump list'.var_dump($list).'<br>';
					//vars to shove into the theme array...
					for ($i = 0; $i < count($list); $i++) {
						//echo '<br>entering second for loops<br>';
						$name = $list[$i]->themeName;
						$author = $list[$i]->themeAuthor;
						$url = $list[$i]->themeURL;
						$description = $list[$i]->themeDescription;
						$image = $currentThemeFolder."theme.jpg";
						$dir = $currentThemeFolder;
						$active = "false"; // just assume theme is unactive for now...
						//echo "<br>vars: ".$name.' '.$author.' '.$url.' '.$description.' '.$image.' '.$dir.' '.$active.' <br>';
					// put the above vars into the $themes array...
					//themesList($name, $dir, $description, $url, $author, $image, $active); // problem is with this call
					array_push($this->themes,array(
      'name' => $name,
	  'directory' => $dir,
      'description' => $description,
      'uri' => $url,
	  'author' => $author,
	  'image' => $image,
	  'activeTheme' => $active
    ));
				}
		}
		//echo '<br>exiting get themes function...<br><br>';
  }
  
  // get an array of all $themeDir/theme.xml files that exists in the /themes dir
  public function scanDirectories($themeDir){
	  //echo 'calling scanDirectories<br>';
	  $comp = "theme.xml";
  //$outs = Array();
    if(file_exists($themeDir) && is_dir($themeDir)){
        // Scan the files in this directory
        $result = scandir($themeDir);
        
        // Filter out the current (.) and parent (..) directories
        $files = array_diff($result, array('.', '..'));
        //print_r($files);
        if(count($files) > 0){

            foreach($files as $file){
                if(is_file("$themeDir/$file")){
                    // Display filename
                    //echo $file . " = ".gettype($file)."<br>";

					if ($file == $comp){
					//echo 'match...<br>';
					array_push($this->outs, "$themeDir/$file");
					
					}
                } else if(is_dir("$themeDir/$file")){
                    // Recursively call the function if directories found
                    $this->scanDirectories("$themeDir/$file");
                }
            }
        } else{
           // echo "ERROR: No files found in the directory.";
        }
    } else {
      //  echo "ERROR: The directory does not exist.";
    }
	//echo gettype($returning);
	//print_r($this->outs);
	return $this->outs;
}

  // find out if the $dir in which there is a theme is actually a valid theme,
  // to be valid the theme must only have, folder includes, theme.xml, and theme.jpg
  // if these files are not found, then the theme is not valid
  public function isThemeVaild($dir){
	$valid = false;
    if ($handle = opendir('$dir')) {
		while (false !== ($entry = readdir($handle))) {
		if ($entry != "." && $entry != "..") {
		if ( file_exists('theme.xml') && file_exists('theme.jpg') && file_exists('\includes'))
		{
			$vaild = true;
			break;
		}
	}
  }
 }
 
  
 return $valid;
}

  // method to set the active theme
  public function setActiveTheme($theme){
  // this will be based only on what is checked on the themes form in admin area...
  
  // first open the activeTheme.xml file to write the new value to...
  
  $xml = new DOMDocument();
    $xml->load($this->activeThemeFile);
      //var_dump($xml);
// loop through the nodes to find the correct one to update...
$record = $xml->getElementsByTagName('theme');
    foreach ($record as $person) {
		    //echo '<br>PERSON: '.$person->getElementsByTagName('activeTheme')->item(0)->nodeValue;
            $person->getElementsByTagName('activeTheme')->item(0)->nodeValue = $theme;
	}
  $xml->save($this->activeThemeFile);
  }
  
 public function ATF (){
	 //echo "DIR: ".dirname(__FILE__);
	 //echo "file: ".$this->activeThemeFile;
	 $url = "http".(!empty($_SERVER['HTTPS'])?"s":"").
"://".$_SERVER['SERVER_NAME']."/phpson/admin/";

echo "URL: ".$url."<br>";
	 $result = simplexml_load_file($url.$this->activeThemeFile);
if ($result === false) 
        {
            echo "Failed loading XML: ";
            foreach(libxml_get_errors() as $error) 
                {
                    echo "<br>", $error->message;
                }
        } 
var_dump($result, $http_response_header);
 }
  
  // method to get the currently set active theme
  public function getCurrentActiveTheme(){
	  //return $this->currentActiveTheme;
	  
	  // $url = "http".(!empty($_SERVER['HTTPS'])?"s":"").
//"://".$_SERVER['SERVER_NAME']."/phpson/admin/";
	  $xml = simplexml_load_file($this->activeThemeFile) or die('file not loadededed');
					
					$list = $xml->activeTheme;
					//var_dump($list);
					for ($i = 0; $i < count($list); $i++) {
						$value = $list[$i];
					}
					$this->currentActiveTheme = $value;
					return $value;
					
  }
  
    // method to get the currently set active theme
  public function getCurrentActiveTheme2(){
	  //return $this->currentActiveTheme;
	  
	  // $url = "http".(!empty($_SERVER['HTTPS'])?"s":"").
//"://".$_SERVER['SERVER_NAME']."/phpson/admin/";
	  $xml = simplexml_load_file($this->activeThemeFile2) or die('file not loadededed');
					
					$list = $xml->activeTheme;
					//var_dump($list);
					for ($i = 0; $i < count($list); $i++) {
						$value = $list[$i];
					}
					$this->currentActiveTheme = $value;
					return $value;
					
  }
  
  // method to find out if theme is active or not 
  public function isThisThemeActive($theme){
	$xml = simplexml_load_file($this->activeThemeFile) or die('file not loaded');
					
					$list = $xml->activeTheme;
					//var_dump($list);
					for ($i = 0; $i < count($list); $i++) {
						//echo 'list; '.$list[$i].'   $theme:  '.$theme.'<br><br>';
						if(strcasecmp($list[$i], $theme) == 0){return true; break;}
					}		
	
	return false;
  }
  
  // method to get a file from the theme, typically would be header.php, footer.php, menu.php
  // but could also be any css, js, php, html file needed for theme display/use....
  public function getThemePart($path, $file){
  // get the active theme, so we know which theme we are working with...
  $currentThemeActive = $this->getCurrentActiveTheme2();
 
  // get the directory of the current active theme...
  $arrayThemes = $this->themes;
  foreach($arrayThemes as $key => $value)
  {
	  if (strcasecmp($value['name'], $currentThemeActive) == 0)
		 // if ($value[$name] === $currentThemeActive)
	  {$currentDir = $value['directory']; }	  
  }
  $output = '';
  
  //echo $currentDir.$path.'/'.$file.'<br><br>';
  
  // assuming a linux server, probly wont work on windoze seervers...
  $output = file_get_contents($currentDir.$path.'/'.$file);
  return $output;
 }
 
 
 // method to get any available templates from the active theme to display/use on creating/editing
 // pages
 public function getTemplates($themeDir){
	// echo '<br>entering get templates function...<br><br>';
	// get the active theme, so we know which theme we are working with...
   $currentThemeActive = $this->getCurrentActiveTheme();
   //$currentDir = $this->themeDir;
   // get the directory of the current active theme...
   $out = array();
  $arrayThemes = $this->themes;
  foreach($arrayThemes as $key => $value)
  {
	  if (strcasecmp($value['name'], $currentThemeActive) == 0)
		 // if ($value[$name] === $currentThemeActive)
	  {$currentDir .= $value['directory']; }	  
  }
  
  //echo "<br>Current dir: ".$currentDir."<br>";
  $currentDir .= "templates/";
  //echo "<br>Current dir: ".$currentDir."<br>";
   if(file_exists($currentDir) && is_dir($currentDir)){
	   //echo '<br><br>is a dir<br><br><br>';
  // next simply get a list of available files in the /templates directory
  // cant hardcode this , needs to finds a way to get the right files paths..
 if ($result = scandir($currentDir)){
	  // echo '<br><br><br>scandir returns true...<br><br><br>';
        //print_r($result);
        // Filter out the current (.) and parent (..) directories
        $files = array_diff($result, array('.', '..'));
       // echo 'FILES: '; print_r($files); echo '<br><br><br>';
        if(count($files) > 0){
        //  echo 'Count gt 0 <br><br><br>';
            foreach($files as $file){
			//	echo 'entering for loops...<br><br><br>';
                //if(is_file($file)){
				//	echo 'is file...<br><br><br>';
                    // for now just Display filename
                  //  echo 'File: -> '.$file . ' = '.gettype($file).'<br>';
					// add each file to an array to return
					array_push($out,$file);
				//}
			}
		}
   }
 else {echo "returned falseo";}
 }
 return $out;
 }
 
 
 
 // method to get the specific template used by a page...
 public function getTemplatePart($file){
	// get the active theme, so we know which theme we are working with...
   $currentThemeActive = $this->getCurrentActiveTheme2();
   //$currentDir = $this->themeDir;
   // get the directory of the current active theme...
  $arrayThemes = $this->themes;
  foreach($arrayThemes as $key => $value)
  {
	  if (strcasecmp($value['name'], $currentThemeActive) == 0)
		 // if ($value[$name] === $currentThemeActive)
	  {$currentDir .= $value['directory']; }	  
  }
  // add the /templates directory
  $currentDir .= "templates/";
  $requestedFile = $currentDir.$file;
  // return the contents of the requested file (template)
  //echo '<br><br>Request file: '.$requestedFile.'<br><br>';
  $output = '';
  
  //echo $currentDir.$path.'/'.$file.'<br><br>';
  
  // assuming a linux server, probly wont work on windoze seervers...
  $output = file_get_contents($requestedFile);
  return $output;
 }
 
 
 
 
 
 // method to get all the themes from the $themes array, which should already be populated before
 // this method is even called...
 // this method is used to build out the themes page in the admin area...
 public function getAllThemes(){
	 $themeList = $this->themes; // all themes

	 // echo the top of the form part....
	 echo '<form id="themeActive" action="themeSetActive.php" method="POST" >';
	 // loop through all themes
	 foreach($themeList as $key => $value){
		 // build out the alert/collapse container for each theme...
		 echo '
		 <div class="row p-2">
 <div class="alert bg-light text-dark p-1 m-2 row w-100"><div class="col-sm"><h5>'.$value['name'].'</h5></div><div class="col-sm"><h6 class="muted">'.$value['author'].'</h6></div><div class="col-sm"><a class="btn btn-primary btn-sm" data-toggle="collapse" href="#collapseExamples'.$value['name'].'" role="button" aria-expanded="false" aria-controls="collapseExamples'.$value['name'].'">Theme Information</a></p></div><div class="col-sm"><div class="form-check">
  <input class="form-check-input" type="radio" name="exampleRadios" value="'.$value['name'].'"'; 
  $checked = $value['name']; 
  if($this->isThisThemeActive($checked)){echo 'checked';} else {echo 'NOTCHECKED';}
  echo ' >
  <label class="form-check-label" for="exampleRadios1">
    Active Theme
  </label>
</div></div>
<!-- theme info collapse modals -->
<div class="collapse alert bg-light text-dark" id="collapseExamples'.$value['name'].'">
<h2 class="text-center p-2">Theme Information</h2>
<h3>Theme Author: '.$value['author'].'</h3>
<p class="text-center mx-auto"><img src="'.$value['image'].'" class="img-fluid" width="400px" height="300px" alt="photo" /></p>
<p><a href="'.$value['uri'].'" class="btn btn-primary btn-sm" target="_blank">Theme URL</a></p>
<p>'.$value['description'].'
</p>';
//<a class="btn btn-primary" href="../admin/editThemeFile2.php?themeName='.$value['name'].'" target="_blank">Edit Theme Files</a>

echo '<button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target=".bd-example-modal-lg'.$value['name'].'">Edit Theme Files</button><div class="modal bd-example-modal-lg'.$value['name'].'">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myLargeModalLabel">Editing '.$value['name'].' Theme</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">';
        //This is modal : '.$value['name'].' ';
		
		$this->getsFiles($value['name']);
		
		
		
		echo '</div>
    </div>
  </div>';
  
  
  echo '<button type="button" class="btn btn-primary mr-2" data-toggle="modal" data-target=".bd-example-modal-lg2'.$value['name'].'">Create New Theme Files</button><span class="btn btn-primary disabled">*Please use with caution and backup theme files before editing*</span><div class="modal bd-example-modal-lg2'.$value['name'].'">
  <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="myLargeModalLabel">Add Files to '.$value['name'].' Theme</h4>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">
        <h2 class="text-center">Create New Theme Files for: '.$value['name'].'</h2> <br><br>
		
		<div class="text-center mx-auto pt-5"><a class="btn btn-primary mb-3" target="_blank" href="addTemplateFile.php?themeFileName='.$value['name'].'">Create New Template File For: '.$value['name'].'</a></div>
		
		<div class="text-center mx-auto pt-5"><a class="btn btn-primary mb-3" target="_blank" href="addIncludeThemeFile.php?themeFileName='.$value['name'].'">Create New Includes File For: '.$value['name'].'</a></div>
		
		<div class="text-center mx-auto pt-5"><a class="btn btn-primary mb-3" target="_blank" href="addCssThemeFile.php?themeFileName='.$value['name'].'">Create New CSS File For: '.$value['name'].'</a></div>

					</div>
		</div></div></div></div></div>';
	 }
 }


// This function takes a theme directory variable and then goes through the directory, ignoring non-editable files (images 
// and such), while printing a button to allow the editable files to be edited...
public function getsFiles($themeDirectory){
	//echo "SERVER ROOT:".$_SERVER['DOCUMENT_ROOT']."<br><br><br>";
	//echo "File Root:".__FILE__."<br><br>";
	//echo '<form id="saveThemeFile" method="post" action="editThemeFile.php">';
	
	//$filePathRemover = __FILE__."/admin/themeClass.php";
	$filePathRemover =  str_replace("/admin/themeClass.php", "", __FILE__);
	//echo "<br><br>FilePathRemover: ".$filePathRemover."<br><br>";
	//echo "Script Name:".$_SERVER['SCRIPT_NAME']."<br><br>";
	$dir = '../themes/'.$themeDirectory;
	
	    if(file_exists($dir) && is_dir($dir)){
        // Scan the files in this directory
        $result = scandir($dir);
        
        // Filter out the current (.) and parent (..) directories
        $files = array_diff($result, array('.', '..'));
        //print_r($files);
		// exclude image files and xml files as these files should not be editable...
		$extensions = array('jpg', 'jpeg', 'png', 'gif', 'bmp', 'webp', 'ico', 'xml');
        if(count($files) > 0){
          //$index = 0;
		  
		  //echo $index.'<br>';
		  //echo '<form id="saveThemeFile" method="post" action="editThemeFile.php">';
            foreach($files as $file){
                if(is_file("$dir/$file") && (!in_array(strtolower(pathinfo($file, PATHINFO_EXTENSION)),$extensions))){
					$digits = 3;
		  $index = rand(pow(10, $digits-1), pow(10, $digits)-1);
                    // Display filename
                    //echo "<br>".$dir.$file . " = ".gettype($file)."<br>";
                    //echo "<br><br>Realpath: ".realpath("$dir/$file")."<br><br>";
			//echo "Realpath: ".str_replace($filePathRemover, "", realpath("$dir/$file"))."<br><br>";
			$link = str_replace($filePathRemover, "", realpath("$dir/$file"));
			//echo '<a href="'.$link.'" target="_blank"  onclick="openForm()">Edit: '.$link.'</a><br>';
			//echo '<a target="_blank">Edit: '.$link.'</a><br>';
			echo '<br><a class="btn btn-primary mb-3" target="_blank" href="editThemeFile.php?themeFileName='.$link.'">Edit: '.$link.'</a><br>';
			


					if (!is_file("$dir/$file")){
					echo '<br><br>Not a file...<br>';
					//array_push($this->outs, "$themeDir/$file");

					}
				}
                 else if(is_dir("$dir/$file")){
                    // Recursively call the function if directories found
                    $this->getsFiles("$dir/$file");
                } //$index++;
            }
			
        } else{
           // echo "ERROR: No files found in the directory.";
        }
    } 
	
		else {
      //  echo "ERROR: The directory does not exist.";
    }

}
	
}
?>