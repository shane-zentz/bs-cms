<?php
// get the file name / path that we're gonna edit:
//echo $_GET['themeFileName']; // the theme name:
//$themeFileName = $_GET['themeFileName'];

// just some style for this page:
echo '<style>
body{
background-color: #091e33 !important;
color: white !important;
}
.text-center {position:relative;margin: 0 auto; text-align:center;}
</style>';

// it's missing the .. , so add it in, justin case...
$themeFileName = '..'.$_GET['themeFileName'];
echo '<h1 class="text-center">Editing Theme File: '.$themeFileName;

// ok, so far so good...
echo '</h1><br><br>';

// get the file into an variable:
$readFile = file_get_contents($themeFileName);

// and now get the file into the text area so it can be edited....
echo '<div class="text-center"><form id="saveThemeFile" name="saveThemeFile" method="post" action="editThemeFile2.php">
<input type="text" name="themeDirFile" value="'.$themeFileName.'" hidden><br>
<textarea rows="16" cols="100" form="saveThemeFile" name="themeFileData">'.$readFile.'</textarea><br>
<input type="submit" form="saveThemeFile" name="submitANDsave" value="Save This File!"></form></div>';



?>