<?php
echo '<style>
body{
background-color: #091e33 !important;
color: white !important;
}
.text-center {position:relative;margin: 0 auto; text-align:center;}
</style>';
echo '<h1 class="text-center">Creating Theme Includes File: '.$_POST['includesFileName'].'</h1>'; // the theme name:
echo '<h2 class="text-center">For theme dir: '.$_POST['themeDir'];
$themeFileName = $_POST['includesFileName'];
$fullThemeFileName = $_POST['themeDir'].$themeFileName;
echo '<h2 class="text-center">Full path and filename: '.$fullThemeFileName.'</h2><br><br>';

//echo 'Theme file data variable: '.$_POST['themeFileData'];
$addContents = $_POST['includeFileContents'];
echo 'File Contents:'.$addContents;
$addContents2 = htmlspecialchars($_POST['includeFileContents']);

// next try to write the file...  // needs to make sure file already doesn't exist
if(!empty($addContents) && !file_exists($fullThemeFileName)){
           file_put_contents($fullThemeFileName, $addContents);
			     
        header("reload:2"); // really should be a fully qualified URI
	    echo '<script type="text/javascript">alert("Theme Includes File Added...... \n Please close this window!");</script>';
			     
}
else {echo '<script type="text/javascript">alert("File Contents Empty?");</script>';}


	
	
?>