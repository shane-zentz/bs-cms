<?php

/*
passwordResult.php
2024 (c) Shane Zentz

* This file just outputs the encrypted password, with which the user can paste into the login.json file to be able
  to regain entry to their bs-cms install....
  
  $2y$10$e3KNDeEqAZ0eFx62I4iXje0ldy\/yXdjOiSTj8872JHVvT4cLzKMZi
*/

$newPassword = $_POST['newPassword'];
?>
<h1>Your new password is:</h1>
<h2>
<?php
//echo $newPassword;
$newerPassword = password_hash($newPassword, PASSWORD_BCRYPT);
echo '<br>'.$newerPassword;
?>
</h2>
<h3>Please copy/paste this code into the login.json file to replace your existing (lost/forgotten) password in order to re-gain access to your BS-CMS installation!</h3>

 