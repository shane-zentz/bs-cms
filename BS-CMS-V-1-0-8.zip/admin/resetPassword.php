<?php
/*
resetPassword.php
5-16-2024 (c) Shane Zentz

* This file will just output an encrypted password which the user (who has lost their password) can manually update
the login.json file with the password put out by this here function....
*/

?>

<h1>Choose a new password</h1>
<form name="createNewPassword" method="post" action="passwordResult.php">>
  <label for="newPassword">Please Enter Your New Password (plaintext):</label><br>
  <input type="text" id="newPassword" name="newPassword"><br>
  <input type="submit" name="submitpassword" value="Get New Password">
</form>





