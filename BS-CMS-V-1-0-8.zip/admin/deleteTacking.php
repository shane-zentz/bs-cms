<?php
    $filename = 'database/visitors.txt';
	$file = $filename;
	// open the visitors file in write mode
	$fp = fopen($file, "r+");
    // clear content to 0 bits
    ftruncate($fp, 0);
    //close file
    fclose($fp);
	// alert user..
	echo '<script type="text/javascript">alert("Tracking History Cleared...");</script>';
header("refresh:0; index.php"); // really should be a fully qualified URI';



?>