<?php
/* 
BS-CMS (c) 2020 by Shane Zentz
this is the login processing part of BS-CMS
*/
session_start();
require_once('cmsClass.php');



$cms = new CMS();


$pass = $_POST["Password"];
$user = $_POST["UserName"];


echo $pass.'<br>';
echo $user.'<br>';



if ($cms->verifry('login.json', $user, $pass)){
	
	$_SESSION['username'] = $user;
	$_SESSION['nID'] = 1;
	echo '<div class="alert alert-sucess alert-dismissible" role="alert">
  logged in!  You will be redirected in 3 seconds...
  <button type="button" class="close" data-dismiss="alert" aria-label="Close">
    <span aria-hidden="true">&times</span>
</div>';

	header("Location: index.php");
	echo "You will be redirected in 3 seconds...";
}
else {
	header("Location: admin-login.php");
$cms->endSession();
}


?>