<?php
/*
BS-CMS (c) 2020 by Shane Zentz
This file is simply used to update the password of the user...
*/
session_start();

if (!isset($_SESSION['nID']))
{
    header("Location: admin-login.php");
    die();
} 

require 'userClass.php';
require_once('activityClass.php');

// create new user object
$user = new User();
$act = new Activity();

// get the data from the form submit
$updateUser = $_POST['userName'];
$updatePass = $_POST['updateUserPass'];

// b4 calling the method just check the vars first....
//echo 'User: '.$updateUser.'   Pass:'.$updatePass.'<br>';

if($user->updateUser ($updateUser, $updatePass)){
  $act->addActivity($updateUser, "Password Updated...");
  header("refresh:0; index.php"); // really should be a fully qualified URI
  echo '<script type="text/javascript">alert("Users Password Has Been Updated...");</script>';
}
else{}
?>